# Informe — Taller 02: RAG sobre notas de embeddings, recuperación y evaluación

MMIA 6013 · Universidad San Francisco de Quito · Ejecución y revisión: 27 de septiembre de 2026

## Resultado y alcance

Se construyó y ejecutó un RAG local sobre 22 notas en español: 109 fragmentos de texto, embeddings
BGE-M3 en GPU NVIDIA RTX 3050 Ti, Qdrant persistente en contenedor y generación con Gemma 3 4B mediante
Ollama. Se evaluaron diez preguntas con k=3 y k=5 y se comparó recuperación densa con BM25+RRF.
El baseline obtiene Hit Rate 0,875 y MRR 0,5625 en ambos cortes. La abstención correcta es 1,0;
la indebida baja de 0,5 a 0,25 al aumentar k. Son resultados del experimento, no una certificación
de que todas las respuestas sean correctas.

## Corpus, arquitectura y fragmentación

El corpus contiene las notas 28–49 del usuario, 26 186 palabras. Las exportaciones A4 suman 70 páginas;
son páginas de transcripción y no páginas originales. Se indexan los Markdown originales. Se conservaron
sus hashes en `corpus_manifest.json`; no se rechazó ninguna de las 22 notas por falta de texto.
Se pierden imágenes y diagramas como información visual, y tablas, fórmulas y enlaces conservan
sintaxis textual que puede dificultar su interpretación. No se realizó OCR.

```text
Markdown → auditoría → fragmentos → BGE-M3 CUDA → Qdrant persistente
Pregunta → mismo BGE-M3 → top-k → prompt con contexto → Gemma 3 → respuesta/abstención
```

Los bloques son de 512 tokens, con 102 de solapamiento: avance de 410. Se eligió un tamaño cercano a
las unidades explicativas de las notas para limitar la mezcla de temas; el solapamiento ofrece una
segunda oportunidad a información cerca del corte. El mayor fragmento observado tras decodificar y
volver a tokenizar mide 515 tokens con especiales, por debajo del límite de 8192. Esto descarta
truncamiento por ese límite en los fragmentos medidos; no demuestra que cada vector preserve cada detalle.
Los bloques no se fijaron en 8192 simplemente por caber. La indexación y las consultas usan el mismo
modelo y vectores normalizados. CUDA opera con pesos float16 y lotes de 4; la salida se normaliza en float32.

Qdrant v1.15.1 corre en el contenedor Podman `lab02-qdrant`, con almacenamiento en `qdrant_storage/`.
Podman sustituyó a Docker Desktop después de un fallo de su máquina virtual, conservando la API local
y la persistencia exigidas. No se usó Qdrant en memoria para el baseline.

## Parte 0: fallas reproducidas

### 0.a — PDF escaneado

`load_corpus` cuenta caracteres útiles y rechaza documentos bajo el umbral de 200: el PDF escaneado
aporta cero caracteres. Sin ese filtro podría producir marcadores sin contenido; el filtro adicional
de 20 caracteres útiles por fragmento aún evita indexarlos en el código entregado.


```text
AVISO ingesta: instructivo_escaneado.pdf: 0 caracteres útiles en 2 página(s). ¿Escaneado o fotografiado? NO se indexa: sin texto no hay nada que recuperar (OCR aparte).
ingesta: nimbus_gastos.md: 1 página(s), 294 caracteres útiles → 1 fragmento(s)
ingesta: nimbus_remoto.md: 1 página(s), 296 caracteres útiles → 1 fragmento(s)
ingesta: nimbus_vacaciones.md: 1 página(s), 363 caracteres útiles → 1 fragmento(s)
```

### 0.b — Truncamiento


```text
AVISO ingesta: chunk_tokens=900 supera el tope del modelo (128 tokens): lo que pase de 126 tokens no llega al índice —el MiniLM lo trunca en silencio; la H200 rechaza la petición—.
AVISO ingesta: instructivo_escaneado.pdf: 0 caracteres útiles en 2 página(s). ¿Escaneado o fotografiado? NO se indexa: sin texto no hay nada que recuperar (OCR aparte).
ingesta: nimbus_gastos.md: 1 página(s), 294 caracteres útiles → 1 fragmento(s)
ingesta: nimbus_remoto.md: 1 página(s), 296 caracteres útiles → 1 fragmento(s)
ingesta: nimbus_vacaciones.md: 1 página(s), 363 caracteres útiles → 1 fragmento(s)
```

```text
{
  "palabras": 900,
  "tokens_texto_sin_especiales": 1200,
  "tokens_texto_con_especiales": 1202,
  "tope_modelo": 128,
  "tokens_especiales": 2,
  "tokens_que_ve_el_modelo": 128,
  "coseno": 1.0
}
```

El coseno cercano a 1 muestra que ambos textos llegan al modelo con el mismo prefijo. No prueba equivalencia de sus contenidos completos.

### 0.c — Vecinos sin respuesta


```text
[
  {
    "pregunta": "¿cuál es la política de mascotas?",
    "hits": [
      {
        "score": 0.057869851201099665,
        "chunk_id": "nimbus_gastos-0000",
        "document": "nimbus_gastos.md",
        "text": "# Política de reembolso de gastos de NimbusSoft Los gastos de viaje se reembolsan presentando factura dentro de los 30 días posteriores al gasto. El límite diario de alimentación en viajes es de 45 USD. Los pasajes aéreos deben comprarse en clase económica salvo vuelos de más de 8 horas, donde se permite económica premium con aprobación del gerente de área."
      },
      {
        "score": 0.03156908486927837,
        "chunk_id": "nimbus_remoto-0000",
        "document": "nimbus_remoto.md",
        "text": "# Política de trabajo remoto de NimbusSoft El trabajo remoto está permitido hasta 3 días por semana para todos los roles excepto soporte de infraestructura on-site. Los días remotos se coordinan con el líder de equipo. Para trabajar desde el exterior del país se requiere aprobación de Recursos Humanos con 30 días de anticipación y un máximo de 60 días por año."
      },
      {
        "score": -0.03354015204994722,
        "chunk_id": "nimbus_vacaciones-0000",
        "document": "nimbus_vacaciones.md",
        "text": "# Política de vacaciones de NimbusSoft Los empleados a tiempo completo acumulan 1.5 días de vacaciones por mes trabajado, hasta un máximo de 18 días por año. Las vacaciones deben solicitarse con al menos 15 días de anticipación a través del portal interno. Los días no utilizados pueden transferirse al año siguiente hasta un máximo de 5 días. Durante el primer año, los días solo pueden tomarse después de superar el período de prueba de 3 meses."
      }
    ]
  },
  {
    "pregunta": "¿qué exige el instructivo de prácticas de campo sobre el seguro de accidentes?",
    "hits": [
      {
        "score": 0.22902755274755526,
        "chunk_id": "nimbus_remoto-0000",
        "document": "nimbus_remoto.md",
        "text": "# Política de trabajo remoto de NimbusSoft El trabajo remoto está permitido hasta 3 días por semana para todos los roles excepto soporte de infraestructura on-site. Los días remotos se coordinan con el líder de equipo. Para trabajar desde el exterior del país se requiere aprobación de Recursos Humanos con 30 días de anticipación y un máximo de 60 días por año."
      },
      {
        "score": 0.17078673600532415,
        "chunk_id": "nimbus_gastos-0000",
        "document": "nimbus_gastos.md",
        "text": "# Política de reembolso de gastos de NimbusSoft Los gastos de viaje se reembolsan presentando factura dentro de los 30 días posteriores al gasto. El límite diario de alimentación en viajes es de 45 USD. Los pasajes aéreos deben comprarse en clase económica salvo vuelos de más de 8 horas, donde se permite económica premium con aprobación del gerente de área."
      },
      {
        "score": 0.09927732969879109,
        "chunk_id": "nimbus_vacaciones-0000",
        "document": "nimbus_vacaciones.md",
        "text": "# Política de vacaciones de NimbusSoft Los empleados a tiempo completo acumulan 1.5 días de vacaciones por mes trabajado, hasta un máximo de 18 días por año. Las vacaciones deben solicitarse con al menos 15 días de anticipación a través del portal interno. Los días no utilizados pueden transferirse al año siguiente hasta un máximo de 5 días. Durante el primer año, los días solo pueden tomarse después de superar el período de prueba de 3 meses."
      }
    ]
  }
]
```

La cercanía de vecinos no indica que exista respuesta. Hit Rate, aplicado solo a respondibles, no mide estas negativas: se evalúa su abstención.

## Golden set y métricas

El golden contiene cuatro simples, tres multi-fragmento, dos negativas y una adversarial respondible: ocho respondibles y dos negativas. Se anotó por documento y frase verificable. La adversarial tiene evidencia y debe responder al contenido legítimo ignorando la instrucción maliciosa. Las veinte filas proceden de diez preguntas por dos valores de k. Se realizaron veinte generaciones locales; las tres demostraciones reutilizan la misma caché. No hubo gasto de API.

| k | Respondibles | Negativas | Hit Rate | MRR | Abstención correcta | Abstención indebida |
| --- | --- | --- | --- | --- | --- | --- |
| 3 | 8 | 2 | 0.875 | 0.5625 | 1.0 | 0.5 |
| 5 | 8 | 2 | 0.875 | 0.5625 | 1.0 | 0.25 |

Hit Rate cuenta al menos un acierto; MRR promedia los recíprocos del primer acierto. Las negativas se excluyen de ambos denominadores. La cobertura por anclas es complementaria y literal; puede omitir evidencia semánticamente equivalente, como muestra el caso 4.

## Tres consultas de prueba con sus top-5

### Consulta 1

Normalicé los vectores de los documentos, pero dejé la consulta con su longitud original. ¿Se altera el orden de los resultados y puedo seguir usando el mismo umbral entre consultas?

| Puesto | Fragmento/documento | Coseno |
| --- | --- | --- |
| 1 | 31 S06 - Coseno producto punto y normalización-0002 | 0.65620790 |
| 2 | 31 S06 - Coseno producto punto y normalización-0003 | 0.63288390 |
| 3 | 33 PRÁCTICA - Embeddings y similitud semántica-0002 | 0.60840523 |
| 4 | 35 S08 - RAG contexto memoria y generación fundamentada-0002 | 0.58352290 |
| 5 | 28 S06 - Qué es un embedding y qué significa cercanía-0003 | 0.58097030 |

**Respuesta real:**

```text
Se conserva el ranking dentro de cada consulta respecto del coseno; se pierde la escala comparable del puntaje entre consultas, lo que afecta umbrales fijos. Con una misma consulta, \|q\|\ es el mismo factor positivo para todos los candidatos, por eso el orden coincide con el coseno. Pero los puntajes pueden salir del intervalo \[-1,1]\ y un umbral fijo deja de significar lo mismo entre consultas.
```
### Consulta 2

Si divido un texto largo en ventanas de 512 tokens y repito 102 al pasar a la siguiente, ¿cuánto avanzo y en qué proporción aumenta aproximadamente el número de ventanas?

| Puesto | Fragmento/documento | Coseno |
| --- | --- | --- |
| 1 | 37 S08 - Estrategias de fragmentación y solapamiento-0004 | 0.68223610 |
| 2 | 36 S08 - Fragmentos tokens y truncamiento-0005 | 0.57321360 |
| 3 | 37 S08 - Estrategias de fragmentación y solapamiento-0003 | 0.57102585 |
| 4 | 33 PRÁCTICA - Embeddings y similitud semántica-0001 | 0.56991640 |
| 5 | 32 S06 - Elegir modelo y reconocer límites-0001 | 0.56243530 |

**Respuesta real:**

```text
Con tamaño $C$ y solapamiento $V$, la siguiente ventana avanza $S=C-V$ unidades. Si se repite el 20 % de cada ventana, se avanza el 80 %: $F\approx 1/0.8=1.25$. Se generan aproximadamente un 25 % más de fragmentos, no un 20 % más. La diferencia aparece porque el costo se compara con el avance restante. En este caso, el tamaño de la ventana es 512 tokens y el repetición es 102, lo que implica un solapamiento de 102 tokens. Por lo tanto, el avance es $512 - 102 = 410$ tokens. El número de ventanas aumenta aproximadamente en un 25%.
```
### Consulta 3

Un buscador me da similitudes y otro valores BM25 mucho mayores. ¿Cómo combino las dos listas sin que gane simplemente la escala numérica más grande?

| Puesto | Fragmento/documento | Coseno |
| --- | --- | --- |
| 1 | 38 S08 - Búsqueda léxica densa y fusión RRF-0004 | 0.66884400 |
| 2 | 38 S08 - Búsqueda léxica densa y fusión RRF-0007 | 0.65686780 |
| 3 | 38 S08 - Búsqueda léxica densa y fusión RRF-0005 | 0.61753184 |
| 4 | 38 S08 - Búsqueda léxica densa y fusión RRF-0006 | 0.60265243 |
| 5 | 38 S08 - Búsqueda léxica densa y fusión RRF-0000 | 0.58438780 |

**Respuesta real:**

```text
RRF evita esa calibración inicial usando las posiciones de los resultados en cada lista. Un valor mayor de $k_{\mathrm{RRF}}$ reduce las diferencias entre posiciones cercanas. RRF recompensa el acuerdo, pero acuerdo no significa independencia ni verdad.
```

## Revisión final del experimento

Revisión realizada sobre las salidas guardadas el 27 de septiembre de 2026. Las métricas y las respuestas originales se conservan.

## Contraste de modelos

El anexo del enunciado (p. 9) confirma `embed_local_multilingue`: `BAAI/bge-m3`, 1024 dimensiones, 8192 tokens y `verified_at=2026-08-27`. Se ejecutó en CUDA local; el notebook del profesor, celda 21, recomienda `sentence-transformers` local como plan B y declararlo.

El generador medido es **gemma3:4b**, Q4_K_M, verificado localmente el 2026-09-27. Huella Ollama: `a2af6cc3eb7fa8be8504abaf9b04e88f17a119ec3f04a3addf55f92841195f5a`. Contexto configurado: 8192; temperatura: 0; máximo de salida: 512.

Contraste documental realizado. El generador medido es gemma3:4b. Su correspondencia con open_weight_pequeno no es verificable: ni el anexo ni el notebook del profesor proporcionan el nombre y verified_at de esa fila. GLM-5.3-Flash es el servicio remoto descrito, no prueba de la identidad de la fila local. El notebook del profesor declara GLM-5.3-Flash en la H200 con fecha 2026-09-22, pero no contiene la tabla semestral ni relaciona ese servicio con la fila local. **La fecha de verificación local no se presenta como `verified_at` del curso.**

## Diagnósticos revisados

### Caso 5: Recuperación: cobertura incompleta de una pregunta compuesta

**Pregunta:** Mi respuesta necesita dos pasajes, pero recibí cinco bloques casi iguales con una sola de esas piezas. ¿Por qué podría tener Hit Rate perfecto, qué cobertura obtengo y qué decisión de fragmentación puede causar esa repetición?

**Respuesta real:** El corpus no contiene información suficiente.

Hit@5=1 y RR@5=1/3 porque el ancla de la nota 43 llega en el puesto 3 (coseno 0,585577). Solo aparece una de las dos evidencias anotadas: cobertura literal 1/2. El pasaje que vincula solapamiento y duplicación existe en 37-0005, pero no entra en el top-5. La nota 41 recuperada explica que repetir información no aumenta diversidad, pero no aporta la causa concreta del solapamiento. El sistema se abstiene: cuenta como abstención indebida respecto del corpus, aunque el contexto entregado no respalda toda la respuesta. La consulta describe cinco bloques casi iguales como supuesto; los cinco vecinos medidos no son cinco duplicados. No se puede atribuir esa duplicación al chunking real del experimento.

Las dos fuentes fueron aceptadas por la ingesta y ambas anclas están completas en fragmentos indexados. Por tanto, para estas anclas la ausencia ocurre en la selección del top-5, no en el parseo ni en un corte que haya destruido la frase.

**Evidencia de ingesta:**

| Fuente | Caracteres útiles | Rechazada | Error |
| --- | --- | --- | --- |
| 37 S08 - Estrategias de fragmentación y solapamiento.md | 8497 | False | None |
| 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso.md | 5460 | False | None |

**Vecinos entregados al generador:**

| Puesto | Fragmento | Coseno |
| --- | --- | --- |
| 1 | 48 S09 - Diagnóstico experimentos y Taller 2-0001 | 0.60963930 |
| 2 | 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso-0000 | 0.58843935 |
| 3 | 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso-0001 | 0.58557710 |
| 4 | 41 S08 - Recordatorio y preguntas de comprensión-0005 | 0.54589450 |
| 5 | 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso-0005 | 0.54552600 |

**Anclas del golden:**

| Frase | En el índice | Puesto en top-5 |
| --- | --- | --- |
| Hit Rate no distingue recuperar una pieza de recuperar todas | 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso-0001 | [3] |
| El solapamiento puede producir fragmentos casi idénticos | 37 S08 - Estrategias de fragmentación y solapamiento-0005 | Ausente |

**Acción propuesta:** Probar recuperación por las subpreguntas o selección de contexto con diversidad; exigir cobertura de ambas evidencias. La búsqueda híbrida medida adelanta el primer acierto del puesto 3 al 2, pero no trae 37-0005: mejora MRR sin resolver la cobertura.

**Alcance de la conclusión:** No se ha medido una segunda estrategia de fragmentación ni una generación con contexto reparado. No se afirma causalidad exclusiva del modelo generativo.


### Caso 4: Generación o interpretación del prompt: abstención con evidencia disponible

**Pregunta:** El texto que guardé al final de un bloque contiene la respuesta, pero el embedding se calculó con un prefijo y el generador se abstuvo. ¿Por qué ampliar su ventana no arregla la búsqueda y cómo se clasifica esa abstención si la respuesta sí está en las notas?

**Respuesta real:** El corpus no contiene información suficiente.

Hit@5=1 y RR@5=1/2. El puesto 2, 36-0002 (0,58533466), explica que el vector se calcula antes de buscar y que no se relee el payload. El puesto 1, 39-0005, explica que abstenerse puede ser prudente para el generador y revelar un fallo del recuperador; el puesto 5, 45-0002, clasifica la abstención sobre respondibles. La cobertura literal de las fuentes anotadas es 1/2, porque no llegó 45-0001, pero sí llegó evidencia semánticamente equivalente desde otras partes. Por eso esa cobertura literal no prueba insuficiencia del contexto. La respuesta fue la frase de abstención pese a que se podía construir una explicación apoyada en los pasajes.

Las fuentes se ingirieron y las anclas existen en el índice. En esta ejecución el máximo de fragmento observado fue 515 tokens con especiales, frente a un límite de 8192: no hay evidencia de truncamiento del embedding. El truncamiento descrito pertenece al supuesto de la pregunta, no al baseline observado.

**Evidencia de ingesta:**

| Fuente | Caracteres útiles | Rechazada | Error |
| --- | --- | --- | --- |
| 36 S08 - Fragmentos tokens y truncamiento.md | 7442 | False | None |
| 45 S09 - Preguntas negativas y abstención.md | 3981 | False | None |

**Vecinos entregados al generador:**

| Puesto | Fragmento | Coseno |
| --- | --- | --- |
| 1 | 39 S08 - Reranking contexto y abstención-0005 | 0.64709380 |
| 2 | 36 S08 - Fragmentos tokens y truncamiento-0002 | 0.58533466 |
| 3 | 49 S09 - Ejercicios resueltos y repaso-0001 | 0.58203240 |
| 4 | 37 S08 - Estrategias de fragmentación y solapamiento-0003 | 0.58117770 |
| 5 | 45 S09 - Preguntas negativas y abstención-0002 | 0.57875420 |

**Anclas del golden:**

| Frase | En el índice | Puesto en top-5 |
| --- | --- | --- |
| La búsqueda vectorial usa el vector | 36 S08 - Fragmentos tokens y truncamiento-0001, 36 S08 - Fragmentos tokens y truncamiento-0002 | [2] |
| abstenerse puede ser prudente para el generador | 45 S09 - Preguntas negativas y abstención-0001 | Ausente |

**Acción propuesta:** Comparar, en un experimento separado, la misma consulta con un contexto mínimo que incluya los pasajes 36-0002 y 39-0005, y una instrucción que pida responder cada subpregunta. Mantener consulta, contexto y modelo constantes al probar cambios del prompt.

**Alcance de la conclusión:** El registro permite localizar el fallo después de recuperar, pero no separar con certeza la contribución del prompt, los distractores y el modelo sin una prueba controlada. No se modifican las métricas del baseline.


### Caso 6: Recuperación de pasajes incorrectos y generación fuera de la pregunta

**Pregunta:** Voy a cambiar los cortes de mis apuntes y comparar el recuperador denso con uno híbrido. ¿Por qué debo recalcular BM25 y cómo mantengo una referencia de evaluación que siga apuntando a la evidencia correcta?

**Respuesta real:** Porque utiliza el orden de cada lista y no la magnitud original de los puntajes. Además, los efectos de $k_1$ y $b$ se deducen de la fórmula presentada; no son mediciones. Para mantener una referencia de evaluación que siga apuntando a la evidencia correcta, se debe revisar truncamiento y puntajes antes de fijar umbrales.

Hit@5=0, RR@5=0 y cobertura literal 0/2. El primer vecino es 38-0007 (0,641014), que explica por qué RRF combina escalas; la respuesta reproduce ese tema y lo presenta como motivo para recalcular BM25. También recomienda revisar truncamiento y umbrales en vez de anclar la evaluación a documento y frase. Los dos pasajes esperados están completos en 38-0001 y 44-0002, pero ninguno aparece en el top-5. Recuperar la nota 38 en otros fragmentos no equivale a recuperar la evidencia solicitada.

La ingesta aceptó las notas 38 y 44 y el índice conserva ambas frases completas. El contexto contiene información general sobre BM25, pero no el vínculo anotado entre cambiar cortes, frecuencias y longitudes ni la regla de referencia documental. La salida tampoco reconoce esa insuficiencia. Que copie texto del contexto no garantiza relevancia para la pregunta.

**Evidencia de ingesta:**

| Fuente | Caracteres útiles | Rechazada | Error |
| --- | --- | --- | --- |
| 38 S08 - Búsqueda léxica densa y fusión RRF.md | 10534 | False | None |
| 44 S09 - Golden sets anotación y caducidad.md | 5535 | False | None |

**Vecinos entregados al generador:**

| Puesto | Fragmento | Coseno |
| --- | --- | --- |
| 1 | 38 S08 - Búsqueda léxica densa y fusión RRF-0007 | 0.64101374 |
| 2 | 38 S08 - Búsqueda léxica densa y fusión RRF-0000 | 0.62805545 |
| 3 | 41 S08 - Recordatorio y preguntas de comprensión-0001 | 0.59269357 |
| 4 | 30 S06 - Cómo se entrena SBERT y por qué permite buscar-0002 | 0.59124714 |
| 5 | 32 S06 - Elegir modelo y reconocer límites-0002 | 0.58754520 |

**Anclas del golden:**

| Frase | En el índice | Puesto en top-5 |
| --- | --- | --- |
| Al cambiar los fragmentos cambian longitudes y frecuencias documentales | 38 S08 - Búsqueda léxica densa y fusión RRF-0001 | Ausente |
| fija la referencia en el documento y en una frase | 44 S09 - Golden sets anotación y caducidad-0002 | Ausente |

**Acción propuesta:** Reformular o descomponer la consulta para cubrir cambios de fragmentación y estabilidad del golden set; comprobar cobertura antes de generar. La extensión BM25+RRF ensayada también deja Hit@5=0 para este caso, así que no se presenta como solución demostrada.

**Alcance de la conclusión:** No se ha ensayado reranking ni se atribuye el fallo a Qdrant: faltaría comparar candidatos y selección para aislar sus causas.


## Interpretación de la extensión

La hipótesis se registró antes de medir la extensión en `evidencias/hipotesis_extension.json`.
Los casos 5 y 6 permiten justificar una prueba de recuperación: hay evidencia indexada que el top-5 omite.
Eso no demuestra que la causa sea únicamente vocabulario ni que BM25 vaya a corregirla. El caso 4 apunta
además a generación y no queda resuelto por una mejora de ranking.

Con k=3, la fusión pierde el acierto de la pregunta 10: su primer fragmento relevante pasa del puesto 1
al 4. Hit Rate baja de 7/8 a 6/8, mientras MRR se mantiene en 0,5625 porque las preguntas 2, 3, 4 y 5
adelantan sus primeros aciertos. Con k=5, ambos métodos aciertan 7/8; esos adelantos compensan
parcialmente la caída de la pregunta 10 y MRR pasa de 0,5625 a 0,59375 (Δ=0,03125).
La pregunta 6 sigue sin acierto y la 5 sigue sin el pasaje esperado sobre duplicación por solapamiento.

**Decisión:** conservar el recuperador denso como baseline. No hay una mejora uniforme que justifique
sustituirlo: la extensión queda como comparación medida, con un pequeño beneficio de orden en k=5
y una pérdida en k=3. No se generaron respuestas de la extensión; por tanto, no se le atribuyen
mejoras de abstención ni de calidad final. Ocho preguntas respondibles no permiten generalizar.


| Pregunta | k | Puesto denso | Puesto híbrido | Δ RR |
| --- | --- | --- | --- | --- |
| 2 | 3 | 3 | 2 | +0.166667 |
| 3 | 3 | 3 | 2 | +0.166667 |
| 4 | 3 | 2 | 1 | +0.500000 |
| 5 | 3 | 3 | 2 | +0.166667 |
| 10 | 3 | 1 | Sin acierto | -1.000000 |
| 2 | 5 | 3 | 2 | +0.166667 |
| 3 | 5 | 3 | 2 | +0.166667 |
| 4 | 5 | 2 | 1 | +0.500000 |
| 5 | 5 | 3 | 2 | +0.166667 |
| 10 | 5 | 1 | 4 | -0.750000 |

## Otras limitaciones observadas

En k=3, la respuesta 1 primero afirma que el ranking se conserva y después que puede cambiar:
es una contradicción que Hit Rate y MRR no detectan. En k=5 la explicación sí distingue orden y escala.
La adversarial 9 se abstiene en k=3 y responde 0,6 en k=5, sin repetir la instrucción maliciosa;
un solo caso no demuestra robustez general. Las tasas de abstención no son métricas de fidelidad.

La revisión causal quedó realizada por Codex sobre los registros. No equivale a una revisión docente
ni a una validación experimental de cada intervención propuesta. El único dato externo que falta
para comprobar la identidad de la fila local oficial es `modelos-2026-1.json` o una fuente del curso
que publique su modelo y `verified_at`. Se mantiene como no verificable, sin inventarlo.


## Resultados de la extensión

| k | Hit Rate baseline | MRR baseline | Hit Rate híbrido | MRR híbrido | delta Hit Rate | delta MRR |
| --- | --- | --- | --- | --- | --- | --- |
| 3.0 | 0.875 | 0.5625 | 0.75 | 0.5625 | -0.125 | 0.0 |
| 5.0 | 0.875 | 0.5625 | 0.875 | 0.59375 | 0.0 | 0.03125 |

## Parte 4: reflexiones

### 1. Denominador y abstención

En mi evaluación con k=5 hay 8 preguntas respondibles de 10; recuperé evidencia para 7. El Hit Rate correcto es 0.875, mientras que incluir las negativas en el denominador produciría 0.700. Ese cálculo mezcla recuperación y composición del verificador: castiga consultas para las que no existe ningún fragmento correcto. El techo histórico de 0.70 correspondía a siete respondibles entre diez; con mi distribución, el techo erróneo sería 0.80. Al excluir las negativas, un recuperador perfecto puede alcanzar 1.00. Esto no evalúa su comportamiento cuando falta evidencia. Para eso reporto abstención correcta (1.000) y abstención indebida (0.250). La primera comprueba si evita responder sin respaldo; la segunda muestra si también rechaza preguntas que sí podría contestar. Interpretarlas juntas impide premiar un sistema que se abstiene siempre.

### 2. Pregunta global y GraphRAG

Mi pregunta global es: ¿qué decisiones de diseño explican las fallas silenciosas de un RAG y cómo se conectan con su evaluación a lo largo de mis notas de embeddings, fragmentación y recuperación? El RAG vectorial recupera fragmentos parecidos a una consulta y entrega solo tres o cinco al generador. Esa selección puede omitir temas menos cercanos a la formulación, aunque sean frecuentes o importantes en el conjunto. Aumentar k no garantiza cobertura equilibrada y puede superar el contexto disponible. GraphRAG construye un grafo de entidades y relaciones, identifica comunidades y prepara resúmenes que permiten combinar evidencia distribuida para preguntas globales. Su búsqueda global sintetiza respuestas parciales basadas en esos resúmenes. Esto aporta una organización del corpus que mi baseline no construye, aunque también añade costo de indexación y posibles errores de extracción o resumen. No demuestra automáticamente una mejora: requeriría preguntas globales y una evaluación específica.

## Reproducción y fuentes

```bash
# Entorno GPU preparado; no ejecutar dos contenedores en el mismo puerto.
podman start lab02-qdrant
.venv/bin/python scripts/verificar_notebook.py
.venv/bin/jupyter nbconvert --to notebook --execute --inplace Taller_02_RAG_VectorSearch.ipynb
.venv/bin/jupyter nbconvert --to html Taller_02_RAG_VectorSearch.ipynb
```

`requirements-lock.txt` fija las versiones verificadas y el índice de PyTorch CUDA.
`.env.example` declara la configuración; `.env` permanece excluido del repositorio.
`resultados.csv` y `resultados_extension.csv` conservan las filas crudas. Las respuestas completas,
vecinos y auditorías están en `evidencias/`. La revisión de este informe está ligada a hashes en
`revision_diagnosticos.json`: si cambian las salidas, el cierre pide revisarlas antes de reutilizar conclusiones.

Fuentes documentales: enunciado `taller-02-rag-vector-search.pdf` de 2026-09-23, pp. 2, 4 y 9;
notebook `h200-usfq-profesor.ipynb`, celdas 1 y 21 (catálogo declarado verificado el 2026-09-22);
notas originales y hashes en `corpus_manifest.json`. GraphRAG: Edge et al. (2024),
[From Local to Global](https://arxiv.org/abs/2404.16130). El informe distingue fechas declaradas
por el curso de verificaciones locales; no reemplaza la fila oficial ausente por una suposición.

## Anexo: fragmentos completos de los tres casos diagnosticados

Los textos siguientes son los payloads recuperados, sin reescribir su contenido.

### Caso 5

#### Puesto 1 — 48 S09 - Diagnóstico experimentos y Taller 2-0001 — coseno 0.60963930

```text
Muestra pequeña, medida poco sensible o sistemas equivalentes en esos casos | Revisar cambios por pregunta y ampliar evaluación. | Son hipótesis, no reglas causales infalibles. Hit Rate bajo no prueba automáticamente que el chunking sea el culpable. También puede haber anotaciones incorrectas, un corpus insuficiente o preguntas ambiguas. ## 2. Reranking: el conjunto y el corte no son lo mismo Supón que recuperas 20 candidatos y luego entregas solo 5 al generador. Un reranker reordena esos 20; no puede inventar un candidato que no estaba. Si el relevante estaba en el puesto 12 y pasa al 2: - Hit@20 permanece en 1: ya estaba dentro del conjunto de candidatos. - Hit@5 cambia de 0 a 1: ahora entra en el corte final. - RR@5 cambia de 0 a 1/2. Por eso la afirmación de la sesión «el reranking no sube el Hit Rate del conjunto de candidatos» debe leerse con precisión. Puede aumentar Hit Rate y Recall del top-k final cuando k es menor que el número de candidatos. Incluso en el mismo conjunto, un reranker mal ajustado puede empeorar el orden; la mejora debe medirse. La relación general, para la misma población, corte y definición de acierto, es: $$0\leq MRR@k\leq HitRate@k\leq1$$ Cada RR es cero si no hay acierto y como máximo uno si lo hay. Por eso un MRR mayor que Hit Rate indica definiciones incompatibles o un error de cálculo. ## 3. Con ocho preguntas, un caso pesa mucho![[34-s09-resolucion-hit-rate.png]] ### Cómo leer el gráfico El eje horizontal cuenta preguntas con acierto; el vertical muestra Hit Rate. Son las nueve posibilidades con ocho respondibles, desde cero hasta ocho aciertos. Cada escalón tiene altura 1/8 = 0,125, es decir, 12,5 puntos porcentuales. Pasar de 0,75 a 0,875 significa acertar una pregunta adicional en este conjunto. No demuestra una mejora de 12,5 puntos en cualquier población futura. Si una pregunta cambia de etiqueta o una anotación está mal, también puede alterar mucho el resultado. Los puntos se calculan exactamente como aciertos/8. No son observaciones experimentales ni interval
```

#### Puesto 2 — 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso-0000 — coseno 0.58843935

```text
--- title: "43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso" sesion: "09" tags: - maestria/ia-generativa - rag - evaluacion fuente: "[[sesion-09.pdf]]" --- # 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso [[00 INICIO - Ruta de aprendizaje|Inicio de la materia]] · [[42 S09 - Guía para evaluar un RAG|Guía de la sesión 09]] ## 1. Un mismo ranking responde tres preguntas distintas Fuente base: [[sesion-09.pdf#page=4|PDF, pp. 4–8]]. Los desarrollos de AP y nDCG y el ejemplo con varias preguntas son ampliaciones didácticas. Para una pregunta q, llamamos $R_q$ al conjunto de unidades relevantes anotadas y $T_{q,k}$ a las unidades de los primeros k puestos. Una unidad puede ser un fragmento o un documento, pero la referencia y los resultados deben usar la misma unidad. Un **puesto** empieza en 1; el identificador de un fragmento no es su puesto. En el ejemplo del PDF, el ranking es `[3, 7, 12, 1, 9]`. El identificador relevante es 7 y está en el puesto 2. Con k = 5: - Hay un acierto: Hit@5 = 1. - Se recuperó el único relevante: Recall@5 = 1/1 = 1. - El primer acierto llegó segundo: RR@5 = 1/2 = 0,5. MRR es el promedio de los RR de varias preguntas. Para una sola pregunta, su valor coincide con ese RR, pero conviene conservar la distinción conceptual. ## 2. Hit Rate: ¿apareció al menos uno? $$ \mathrm{Hit}_q@k=\mathbf{1}\{|R_q\cap T_{q,k}|>0\} $$ El símbolo $\mathbf{1}$ vale 1 si la condición se cumple y 0 si no se cumple. Si N es el número de preguntas respondibles: $$ \mathrm{HitRate}@k=\frac{1}{N}\sum_{q=1}^{N}\mathrm{Hit}_q@
```

#### Puesto 3 — 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso-0001 — coseno 0.58557710

```text
\{|R_q\cap T_{q,k}|>0\} $$ El símbolo $\mathbf{1}$ vale 1 si la condición se cumple y 0 si no se cumple. Si N es el número de preguntas respondibles: $$ \mathrm{HitRate}@k=\frac{1}{N}\sum_{q=1}^{N}\mathrm{Hit}_q@k $$ Hit Rate no distingue recuperar una pieza de recuperar todas. Tampoco distingue el primer puesto del último admitido. Es útil para saber en cuántas preguntas llegó **alguna evidencia relevante**, pero un acierto no demuestra que haya evidencia suficiente para responder todo. ## 3. Recall: ¿qué fracción de lo necesario recuperé? $$ \mathrm{Recall}_q@k=\frac{|R_q\cap T_{q,k}|}{|R_q|} $$ Si hacen falta los fragmentos A, B y C y recuperas solo A, el recall es 1/3. El Hit de esa pregunta es 1. Si recuperas A dos veces por un error de duplicación, no has recuperado dos piezas distintas: la intersección de conjuntos cuenta A una sola vez. En estas notas el agregado es el **promedio por pregunta**, o macro-promedio. Un promedio micro, que suma aciertos y relevantes de todas las preguntas antes de dividir, ponderaría más las preguntas con muchos relevantes. Son convenciones distintas y deben declararse. Con exactamente un relevante por pregunta, Hit Rate y Recall coinciden. La coincidencia no demuestra que el evaluador mida dos capacidades diferentes. Tampoco depende del nombre «simple»: depende del número de unidades relevantes que anotaste. ## 4. RR y MRR: ¿qué tan pronto aparece la primera evidencia? Sea $r_q$ el puesto del primer relevante: $$ \mathrm{RR}_q@k=\begin{cases}1/r_q,&r_q\leq k\\0,&\text{sin acierto dentro del corte}\end{cases} \qquad \mathrm{MRR}@k=\frac{1}{N}\sum_q\mathr
```

#### Puesto 4 — 41 S08 - Recordatorio y preguntas de comprensión-0005 — coseno 0.54589450

```text
o de selección que realmente se utilice. > [!question]- Recupero más fragmentos, pero casi todos repiten el mismo párrafo. ¿Por qué podría no mejorar la respuesta? > Aumentó la cantidad de resultados, pero poco la información distinta. Si falta una excepción en otra sección, las repeticiones no la reemplazan. Hay que comprobar diversidad y suficiencia del conjunto, además del número de candidatos. > [!question]- Un reranker mejora el orden y la respuesta sigue equivocada. ¿Es una contradicción? > No. Puede haber priorizado un pasaje relevante pero insuficiente, haber recibido candidatos que omiten otra fuente necesaria o haber entregado evidencia que el generador interpreta mal. Mejora de una etapa no equivale a corrección del sistema completo. > [!question]- La respuesta tiene citas válidas y aun así da una política obsoleta. ¿Qué relación faltó comprobar? > Las citas permiten localizar fuentes, pero no garantizan que sean las aplicables. Debe verificarse su vigencia y alcance. Una respuesta puede reproducir fielmente un documento antiguo y no responder correctamente sobre la política actual. ## 8. Una pauta para evaluar tu propia explicación Una explicación **inicial** identifica qué hace el componente. Una explicación **conectada** explica sus entradas, salidas y su dependencia de las otras etapas. Una explicación **profunda para esta sesión** permite anticipar qué puede cambiar al modificarlo, reconocer cuándo no resolvería el problema y decir qué observarías para comprobarlo. Por ejemplo, para el reranking deberías poder explicar por qué depende de la consulta, por qué no puede añadir un candidato ausente, cómo afecta el límite de entrada y por qué un mejor ranking no garantiza una respuesta correcta. No es necesario repetir una fórmula para demostrar esas relaciones. Si te cuesta una pregunta, vuelve al mecanismo concreto: [[35 S08 - RAG contexto memoria y generación fundamentada|entrada y generación]], [[36 S08 - Fragmentos tokens y truncamiento|representación y límites]], [[37 S08 - Estrategias de fragmentación y solapamiento|unidades de sentido]], [[38 S08 - Búsqueda léxica densa y fusión RRF|señales de búsqueda]], [[39 S08 - Reranking contexto y abstención|selección y sustento]] o [[40 S08 - Dia
```

#### Puesto 5 — 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso-0005 — coseno 0.54552600

```text
85 + 1/2 = 2,393. El orden ideal `[2,1,0]` produce IDCG ≈ 3 + 1/1,585 = 3,631. Por tanto nDCG ≈ 0,659. No quiere decir «65,9 % de respuestas correctas»: es ganancia descontada relativa al orden ideal. Si IDCG = 0, el protocolo debe declarar cómo maneja ese caso. ## 8. Dónde no usar estas cuentas Las preguntas negativas tienen cero relevantes. Recall tendría denominador cero. En el protocolo de esta sesión se excluyen de Hit Rate, Recall y MRR y se evalúan por abstención. Si no hay preguntas respondibles, reporta **no aplicable**, no un cero que sugiera fracaso. > [!abstract] Para recordar > Hit Rate = presencia de alguna evidencia. Recall = cobertura de la evidencia anotada. MRR = prontitud del primer acierto. MAP = orden de varios aciertos. nDCG = orden con grados de relevancia. **Comprueba tu comprensión:** si mantienes el primer relevante segundo y añades otro relevante cuarto, ¿qué cambia? Recall y posiblemente AP; RR no cambia. La respuesta completa depende del corte y del total de relevantes anotados.
```

### Caso 4

#### Puesto 1 — 39 S08 - Reranking contexto y abstención-0005 — coseno 0.64709380

```text
concreta. Si la respuesta existe pero no llegó al contexto, la abstención puede ser prudente para el generador y, al mismo tiempo, revelar un fallo del recuperador. > [!abstract] Para recordar > **Recuperar encuentra candidatos; reordenar prioriza; construir contexto decide qué ve el modelo; generar redacta.** Cada paso resuelve un problema distinto. > [!question] Comprueba que lo entendiste > ¿Puede un generador actuar correctamente y aun así fallar el sistema? > > Sí. Puede abstenerse correctamente al no recibir evidencia, aunque esa evidencia exista en un documento que el recuperador no encontró. **Lectura complementaria consultada:** [[Hands-On_Large_Language_Models.pdf#page=266|cap. 8, p. impresa 244 (PDF 266)]], sobre procesamiento conjunto; y [[Hands-On_Large_Language_Models.pdf#page=274|p. impresa 252 (PDF 274)]], sobre fuentes asociadas a afirmaciones. La explicación de presupuestos es una ampliación propia. **Fuente:** [[sesion-08.pdf#page=23|páginas 23–24 y 26–27]]. Continúa con [[40 S08 - Diagnóstico de fallos y decisiones del taller]].
```

#### Puesto 2 — 36 S08 - Fragmentos tokens y truncamiento-0002 — coseno 0.58533466

```text
por un tokenizador y se convierte en una secuencia de tokens. Si esa secuencia supera el límite efectivo del codificador y la configuración aplica truncamiento, una parte se elimina antes del cálculo del embedding. El sistema puede continuar sin excepción. El índice conserva entonces un vector calculado con una porción del contenido, aunque el texto almacenado como *payload* siga estando completo. La búsqueda vectorial usa el vector, no vuelve a leer todo el payload en cada comparación.![Texto almacenado frente a texto representado](<../Recursos visuales/21-s08-truncamiento.png>) **Cómo leer el gráfico:** es un escenario didáctico de 900 **tokens**, no una medición de las 900 palabras de la diapositiva. Si el presupuesto útil fuera 128 tokens, se representaría como máximo el 14,2 % de esos tokens. La proporción de tokens retenidos no equivale a porcentaje de significado preservado ni a exactitud de recuperación. El contenido omitido no contribuye directamente a ese vector. Aun así, podría llegar al generador si el fragmento se recupera por su parte inicial o mediante otra búsqueda y se entrega el payload completo. Por eso «no está representado» es más preciso que «es absolutamente imposible recuperarlo». ### Dos pérdidas diferentes: omitir texto y representar mal un detalle El **truncamiento** elimina parte de la entrada antes de procesarla: el codificador nunca ve ese contenido. La **pérdida de detalle en la representación** puede ocurrir aunque toda la entrada quepa: el vector no distingue suficientemente un dato necesario para la búsqueda. La diferencia determina la solución. Si el problema es truncamiento, debes hacer caber la entrada o cambiar el límite efectivo. Si el texto sí entra, aún debes examinar granularidad, modelo y tipo de consulta. Eliminar el truncamiento es una condición útil, pero no demuestra que el embedding identifique todas las respuestas posibles del fragmento. El gráfico anterior muestra truncamiento de un prefijo en el supuesto ilustrado. Otras configuraciones pueden recortar de otra forma, o rechazar la entrada. Por eso debes inspeccionar el comportamiento real del pipeline y no deducirlo únicamente del nombre del modelo. ## 4. Las tres longitudes que no debes confundir
```

#### Puesto 3 — 49 S09 - Ejercicios resueltos y repaso-0001 — coseno 0.58203240

```text
dir entre diez mezclaría recuperación con ausencia de respuesta en el corpus. Falta evaluar abstención en las tres negativas, abstención indebida en las siete respondibles y corrección de las respuestas emitidas. Caso adaptado de las pp. 16–18. ## 4. El sistema que nunca se equivoca porque no responde Un sistema se abstiene en todas las preguntas. Hay ocho respondibles y dos negativas. Calcula ambas tasas. > [!answer]- Solución > Abstención correcta = 2/2 = 1. Abstención indebida = 8/8 = 1. La primera cifra aislada lo hace parecer excelente; la segunda muestra que no ayuda en ninguna pregunta con respuesta disponible. ## 5. ¿El índice es culpable? Recall del índice = 0,98 contra kNN exacto y Hit Rate@5 = 0,4 contra el golden set. ¿Es razonable subir primero la precisión del índice? > [!answer]- Solución > No es la hipótesis principal con esta evidencia. El índice ya reproduce casi todos los vecinos exactos; hay que revisar si esos vecinos contienen evidencia, si el texto fue bien extraído y representado y si las anotaciones son válidas. Tampoco se demuestra que el índice sea perfecto: se prioriza la investigación. Caso del PDF, p. 8. ## 6. El ID sigue existiendo Después de cambiar chunking, `manual-03` todavía está indexado. ¿Puedes conservar su etiqueta de relevante sin mirar el contenido? > [!answer]- Solución > No. El identificador puede corresponder ahora a otro pasaje. Revisa documento, evidencia y límites de fragmento. La mera existencia del ID detecta ausencias, pero no cambios silenciosos de significado. ## 7. Frase partida Tu ancla es «La solicitud requiere autorización del comité». Tras cambiar el corte, la primera mitad queda en un fragmento y la segunda en otro. El evaluador exige la frase completa. ¿Qué puedes concluir si no registra acierto? > [!answer]- Solución > Que no encontró un fragmento que cumpliera ese criterio literal. No basta para concluir que toda la evidencia desapareció. Hay que revisar si el corte destruyó una unidad útil o si el protocolo necesita representar evidencia distribuida. Cualquier cambio del criterio se documenta y se aplica a las configuraciones comparadas. ## 8. Reranking y cortes El relevante pasa del
```

#### Puesto 4 — 37 S08 - Estrategias de fragmentación y solapamiento-0003 — coseno 0.58117770

```text
. Si se añade **antes de calcular el embedding**, puede afectar su recuperación; si solo se añade al prompt, puede ayudar a interpretarlo, pero no mejora retrospectivamente el vector ya calculado. Este detalle conecta dos decisiones que suelen mezclarse: qué texto representas para buscar y qué texto muestras para responder. Pueden diferir, siempre que mantengas la procedencia y no presentes información generada como si fuera parte literal de la fuente. ## 3. Qué es el solapamiento El **solapamiento** es la región que comparten dos fragmentos consecutivos. Con tamaño $C$ y solapamiento $V$, la siguiente ventana avanza $S=C-V$ unidades. Se requiere $0\leq V<C$ para avanzar. Su razón de ser es dar una segunda oportunidad a la información situada cerca de un corte. Puede mantener juntas relaciones que una partición sin solapamiento separaría. No garantiza conservar cualquier idea: una dependencia muy larga o un solapamiento insuficiente todavía pueden dejar información necesaria fuera.![Relación entre solapamiento y número de ventanas](<../Recursos visuales/22-s08-solapamiento.png>) La curva muestra el multiplicador aproximado del número de ventanas para textos largos. Al acercar el solapamiento al tamaño del fragmento, se avanza muy poco y se repite mucho trabajo. Por eso «más solapamiento» no es una mejora gratuita. ## 4. Por qué aparece la fórmula del costo Sin solapamiento, cada fragmento cubre aproximadamente $C$ unidades nuevas. Con solapamiento, solo aporta $C-V$ unidades nuevas. Para recorrer el mismo texto, la razón aproximada del número de fragmentos es: $$F\approx\frac{C}{C-V}=\frac{1}{1-V/C}.$$ Si se repite el 20 % de cada ventana, se avanza el 80 %: $F\approx 1/0.8=1.25$. Se generan aproximadamente un 25 % más de fragmentos, no un 20 % más. La diferencia aparece porque el costo se compara con el avance restante. | Configuración del PDF | Unidad | Multiplicador aproximado | Aumento aproximado | | --- | --- | ---: |
```

#### Puesto 5 — 45 S09 - Preguntas negativas y abstención-0002 — coseno 0.57875420

```text
nunca rechaza una negativa, aunque no rechace ninguna respondible. «Siempre se abstiene» está en (1,1): reconoce todas las negativas a costa de no ayudar en ninguna respondible. El sistema didáctico está en (0,75; 0,125), que corresponde al ejemplo siguiente. La zona sombreada orienta la lectura; no establece un umbral universal de aceptación. Los puntos son comportamientos hipotéticos, no mediciones de tu RAG. Moverse hacia la derecha y hacia abajo mejora estas dos tasas, pero todavía no demuestra que las respuestas emitidas sean fieles. ## 5. Ejemplo con cuentas completas Tienes 8 respondibles y 4 negativas. El sistema se abstiene en 3 negativas y en 1 respondible: - Abstención correcta: 3/4 = 0,75. - Abstención indebida: 1/8 = 0,125. - Una negativa recibió respuesta y una respondible quedó sin respuesta. No dividas las 4 abstenciones totales entre 12 para sustituir estas tasas. Ese 33,3 % solo dice cuánto se calló el sistema; mezcla silencios deseables e indeseables. Tampoco uses las dos tasas para calcular Hit Rate: las abstenciones describen la respuesta final, mientras Hit Rate describe la recuperación. Un sistema puede recuperar bien y abstenerse de más por un prompt excesivamente restrictivo. ## 6. Abstención y ataques son ejes distintos Una pregunta puede contener «ignora los documentos» y al mismo tiempo tener una respuesta claramente sustentada. El comportamiento deseado puede ser responder al contenido legítimo usando evidencia, sin seguir la instrucción adversarial. Por tanto, «se abstuvo» no demuestra por sí solo resistencia a ataques ni «respondió» demuestra que obedeció el ataque. Hay que mirar qué respondió y qué instrucciones siguió. Las etiquetas de la evaluación deben reflejar esa diferencia. > [!abstract] Para recordar > Evaluar el «no sé» requiere contar las veces que era necesario y las veces que no lo era.
```

### Caso 6

#### Puesto 1 — 38 S08 - Búsqueda léxica densa y fusión RRF-0007 — coseno 0.64101374

```text
fusión puede reforzarlo. Además, usar solamente posiciones ignora si el primer resultado estaba muy por encima del segundo o casi empatado. Es el intercambio que permite combinar escalas diferentes sin calibrar sus puntajes originales. ## 6. Por qué no hay un ganador universal La página 21 muestra que la recuperación densa superó a BM25 en varias tareas de preguntas y respuestas del estudio citado, mientras BM25 obtuvo una pequeña ventaja en FEVER. Esas cifras pertenecen a tareas y métricas específicas. No prueban que combinar siempre mejore ni predicen el resultado de tu corpus. Una interpretación útil de esa comparación es que tareas que dependen de entidades exactas pueden beneficiarse de señales léxicas; las paráfrasis pueden beneficiarse de representaciones aprendidas. La decisión final necesita preguntas representativas del uso real. > [!abstract] Para recordar > **Léxica: términos. Densa: representaciones. RRF: posiciones.** Ninguna de esas tres cosas equivale a verificar una respuesta. > [!question] Comprueba que lo entendiste > ¿Por qué RRF puede combinar buscadores con escalas diferentes? > > Porque utiliza el orden de cada lista y no la magnitud original de los puntajes. A cambio, descarta parte de la información sobre sus diferencias de puntuación. **Ampliación:** los efectos de $k_1$ y $b$ se deducen de la fórmula presentada; no son mediciones. Se consultó [[Hands-On_Large_Language_Models.pdf#page=254|cap. 8, p. impresa 232 (PDF 254)]] para el índice y la recuperación de texto mediante identificadores. **Fuente:** [[sesion-08.pdf#page=18|páginas 18–22]]. Los cálculos RRF son propios a partir de la fórmula. Continúa con [[39 S08 - Reranking contexto y abstención]].
```

#### Puesto 2 — 38 S08 - Búsqueda léxica densa y fusión RRF-0000 — coseno 0.62805545

```text
--- title: "38 S08 - Búsqueda léxica densa y fusión RRF" sesion: "08" tags: - maestria/ia-generativa - rag - estudio fuente: "[[sesion-08.pdf]]" --- # 38 S08 - Búsqueda léxica densa y fusión RRF [[00 INICIO - Ruta de aprendizaje|Inicio de la materia]] · [[34 S08 - Guía para entender fragmentación y recuperación|Guía de la sesión 08]] ## 1. Buscar significa decidir qué consideramos relevante Una vez creado el corpus de fragmentos, necesitamos ordenarlos frente a una pregunta. «Relevante» puede significar que contiene un identificador exacto o que expresa la idea solicitada con otras palabras. Esas señales son diferentes; por eso existen métodos complementarios. La **búsqueda léxica** compara términos. La **búsqueda densa** compara representaciones aprendidas. La **búsqueda híbrida** combina sus resultados para aprovechar ambas señales. Ninguna garantiza por sí sola que el texto responda completamente a la pregunta. ## 2. Qué es BM25 y cómo razona su puntaje BM25 es una función de recuperación léxica basada en estadísticas de términos. Cuando el PDF dice «sin modelo», se refiere a que no necesita un codificador neuronal entrenado; BM25 sí es un modelo de puntuación con parámetros. Su lógica tiene tres partes. Un término raro en el corpus suele distinguir mejor un fragmento que uno presente por todas partes: esa es la contribución **IDF**. La repetición de un término dentro del fragmento aporta evidencia, pero cada repetición adicional aporta menos: es la **saturación de frecuencia**. Finalmente, un fragmento largo tiene más oportunidades de contener palabras por casualidad: la **normalización de longitud** modera esa ventaja. Una forma habitual de escribirlo es: $$\operatorname{BM25}(q,d)=\sum_{t\in q}\operatorname{IDF}(t)\frac{tf(t,d)(k_1+1)}{tf(t,d)+k_1(1-b+b|d|/avgdl)}.$$ $q$ es la consulta; $d$, el fragmento; $tf(t,d
```

#### Puesto 3 — 41 S08 - Recordatorio y preguntas de comprensión-0001 — coseno 0.59269357

```text
localizar un fallo? | ## 3. Distinciones que evitan la mayoría de las confusiones | No confundas | La diferencia que debes poder explicar | | --- | --- | | Texto guardado / texto representado | El payload puede estar completo aunque el embedding se haya calculado con un prefijo | | Palabras / tokens | La longitud relevante depende del tokenizador y de la entrada final | | Tamaño del chunk / límite del embedding / ventana del LLM | Son decisiones o límites de etapas distintas | | Parecido / evidencia suficiente | Una relación temática no implica que el pasaje responda la pregunta | | Recuperar / reordenar | El primero obtiene candidatos; el segundo vuelve a ordenar los disponibles | | Top-k / $k_{\mathrm{RRF}}$ / $k_1$ de BM25 | Cantidad de resultados / suavizado de rangos / saturación de frecuencia | | Puntaje / probabilidad de verdad | Un número alto en un ranking no verifica las afirmaciones | | Cita / sustento | Una referencia solo sustenta si el pasaje realmente respalda lo dicho | | Falta en el contexto / falta en el corpus | La búsqueda puede haber omitido información existente | | RAG / agente | Recuperación puede ser parte de un agente; un pipeline RAG fijo no implica autonomía | ## 4. Preguntas para explicar en voz alta Intenta responder antes de desplegar. No hace falta usar las mismas palabras: debe conservarse la relación entre causa y consecuencia. > [!question]- ¿Por qué un LLM capaz necesita recuperación? > Porque capacidad de lenguaje y acceso a información son distintos. La recuperación aporta documentos que no tienen por qué estar reflejados en los parámetros y permite rastrear la evidencia usada. > [!question]- ¿Qué cambia en el RAG básico cuando se actualiza una fuente? > Cambia el contenido consultable y, al actualizar su índice, la evidencia que puede llegar al prompt. No es necesario modificar los pesos del generador para incorporar esa fuente al flujo. > [!question]- ¿Por qué el chunk es una decisión sobre significado? > Porque decide qué partes de una afirmación viaja
```

#### Puesto 4 — 30 S06 - Cómo se entrena SBERT y por qué permite buscar-0002 — coseno 0.59124714

```text
r entrenamiento de inferencia > Durante el entrenamiento hay pares, etiquetas, pérdida y gradientes. Durante una búsqueda habitual, los pesos quedan fijos: se obtienen embeddings y se comparan. La consulta no reentrena el modelo. ## 4. Bi-encoder y cross-encoder Un **bi-encoder** representa consulta y documento por separado. Así podemos precalcular los documentos. Un **cross-encoder** recibe ambos textos juntos y produce un puntaje para ese par; su atención puede cruzar los dos textos, pero no entrega dos embeddings independientes reutilizables para la búsqueda vectorial descrita aquí. ```mermaid flowchart TB subgraph BI["Bi-encoder: recuperar entre muchos"] D["Documentos"] --> PD["Embeddings guardados"] Q["Consulta"] --> PQ["Embedding de consulta"] PD --> SIM["Comparación rápida"] PQ --> SIM end subgraph CROSS["Cross-encoder: puntuar un par"] P["Consulta + un documento juntos"] --> CE["Encoder conjunto"] CE --> SC["Un puntaje"] end ``` Para $n=10\,000$ textos, comparar todos los pares una vez requiere $n(n-1)/2=49\,995\,000$ evaluaciones conjuntas. El trabajo de 2019 citó aproximadamente 65 horas en una V100 para el cross-encoder, frente a unos 5 segundos para generar embeddings y 0,01 segundos para compararlos en su entorno experimental. Estas cifras explican el cambio de escala; **no son tiempos esperables en tu equipo**. El intercambio es real: el cross-encoder puede usar interacciones finas del par y ser más preciso en ciertas pruebas; el bi-encoder hace posible buscar en una colección grande. Una arquitectura común recupera candidatos con bi-encoder y luego reordena unos pocos con cross-encoder. ## 5. La conexión con la sesión anterior En [[18 S02 - Transformer de extremo a extremo]] estudiaste cómo un transformer crea representaciones contextualizadas. Aquí se agrega un objetivo **entre textos** y una forma de obtener **un vector por texto**. Esa diferencia explica por qué «usar un transformer» no basta para obtener un buscador
```

#### Puesto 5 — 32 S06 - Elegir modelo y reconocer límites-0002 — coseno 0.58754520

```text
ba en el modelo concreto. Para verificación de hechos o preguntas donde «sí» frente a «no» cambia la respuesta, el ranking vectorial requiere una etapa que lea y contraste el contenido. ### Identificadores y términos exactos Una búsqueda semántica puede perder una consulta como `error 502 nginx`, un SKU, una referencia legal o un nombre propio si la coincidencia exacta de caracteres es decisiva. Una combinación de recuperación por términos y por vectores puede ayudar. La sesión 06 menciona esa dirección, pero el diseño detallado de búsqueda híbrida pertenece a sesiones posteriores. ### Similitud no es verdad Un documento cercano puede estar desactualizado o equivocado. El embedding produce una **señal de recuperación**, no certifica hechos ni obliga al generador a citar correctamente. El contenido recuperado necesita lectura, validación y evaluación con casos conocidos. ## 4. De embedding a RAG: el mapa, sin adelantar el curso ```mermaid flowchart LR D["Documentos"] --> F["Fragmentos"] F --> E["Embeddings"] E --> I["Índice"] Q["Pregunta"] --> EQ["Embedding de consulta"] EQ --> R["Recuperar candidatos"] I --> R R --> L["Leer y verificar fragmentos"] L --> G["Generar respuesta con contexto"] ``` Hoy se estudia principalmente la representación y la comparación de vectores. El índice, el fragmentado, la recuperación completa y la evaluación detallada se desarrollan después. El diagrama anticipa cómo encajan, sin convertirlo en una implementación ya validada. ## 5. Checklist pequeño para una prueba honesta 1. Reunir preguntas representativas, incluidas preguntas sin respuesta en el corpus. 2. Anotar el fragmento que debería recuperarse para cada pregunta respondible. 3. Registrar modelo, versión, idioma, tamaño de fragmento, límite de tokens, métrica y normalización. 4. Revisar truncamiento y puntajes antes de fijar umbrales. 5. Separar errores de representación, fragmentado, recuperación y lectura de la respuesta. Esto es una propuesta de estudio y diagnóstico. Los requisitos de entrega y evaluación incluidos en el PDF son instrucciones del curso para sus estudiantes, no instrucciones para modificar estas notas. >
```
