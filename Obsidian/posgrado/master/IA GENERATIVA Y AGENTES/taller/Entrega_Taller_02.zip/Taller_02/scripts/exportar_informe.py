from pathlib import Path
import json
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/google-chrome',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1280,'height':1000})
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto((root/'Informe_Taller_02.html').as_uri(),wait_until='networkidle')
 page.wait_for_timeout(2500)
 info=page.evaluate('''() => ({tables:document.querySelectorAll('table').length,
   errors:document.querySelectorAll('.MathJax_Error,.mjx-merror').length,
   width:document.documentElement.scrollWidth,viewport:innerWidth,
   text:document.body.innerText.length})''')
 assert info['tables']>=15 and not info['errors'] and not errors
 assert info['width']==info['viewport']
 page.screenshot(path=str(root/'evidencias/render/informe_inicio.png'))
 page.pdf(path=str(root/'Informe_Taller_02.pdf'),format='A4',print_background=True,
  prefer_css_page_size=True,display_header_footer=True,
  header_template='<span></span>',
  footer_template='<div style="font-size:8px;width:100%;text-align:center">Taller 02 · <span class="pageNumber"></span> / <span class="totalPages"></span></div>')
 info['page_errors']=errors
 (root/'evidencias/render/informe_verificacion.json').write_text(json.dumps(info,indent=2)+'\n')
 print(info)
 browser.close()
