"""Prueba real de embeddings CUDA y recuperación, sin Docker ni llamadas al generador."""
from pathlib import Path
import json
import os
import sys
import time

import numpy as np
import torch
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
load_dotenv(ROOT / ".env")
os.environ.update(EMBEDDING_BACKEND="local", EMBEDDING_DEVICE="cuda", QDRANT_URL=":memory:")

from rag_pipeline import EMBEDDING_MODEL, RagPipeline

assert torch.cuda.is_available(), "Instala PyTorch con CUDA en el entorno del notebook."
torch.cuda.reset_peak_memory_stats()
inicio = time.perf_counter()
pipeline = RagPipeline(collection="verificacion_gpu")
assert pipeline.encoder.device.startswith("cuda")
vectors = pipeline.encoder.encode(["La búsqueda vectorial recupera documentos similares.",
                                   "Los embeddings representan el significado de un texto."])
assert np.isfinite(vectors).all()
assert np.allclose(np.linalg.norm(vectors, axis=1), 1, atol=1e-5)
chunks = pipeline.ingest(ROOT / "corpus", chunk_tokens=512, overlap_tokens=102)
assert chunks
pipeline.index(chunks)
pregunta = "¿Qué es la búsqueda híbrida y cómo combina BM25 con embeddings?"
hits = pipeline.retrieve(pregunta, top_k=5)
assert len(hits) == 5 and all(np.isfinite(h["score"]) for h in hits)
torch.cuda.synchronize()
resultado = {
    "modelo": EMBEDDING_MODEL,
    "gpu": torch.cuda.get_device_name(0),
    "torch": torch.__version__,
    "cuda": torch.version.cuda,
    "device": pipeline.encoder.device,
    "dtype": pipeline.encoder.dtype,
    "batch_size": pipeline.encoder.batch_size,
    "dimensiones": vectors.shape[1],
    "documentos": len({c.document for c in chunks}),
    "fragmentos": len(chunks),
    "pico_memoria_asignada_mib": round(torch.cuda.max_memory_allocated() / 2**20, 1),
    "segundos": round(time.perf_counter() - inicio, 2),
    "qdrant": ":memory:",
    "pregunta": pregunta,
    "hits": hits,
}
path = ROOT / "evidencias" / "verificacion_gpu.json"
path.parent.mkdir(exist_ok=True)
path.write_text(json.dumps(resultado, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({k: v for k, v in resultado.items() if k != "hits"}, ensure_ascii=False, indent=2))
print("Top 5:", [h["document"] for h in hits])
print("Evidencia:", path)
pipeline.client.close()
