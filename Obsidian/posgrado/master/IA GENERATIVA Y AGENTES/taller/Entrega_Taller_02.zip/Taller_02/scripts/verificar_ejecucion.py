from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import pandas as pd
import nbformat
root=Path(__file__).resolve().parents[1]
nbpath=root/'Taller_02_RAG_VectorSearch.ipynb'
nb=nbformat.read(nbpath,4)
code=[c for c in nb.cells if c.cell_type=='code']
assert all(c.execution_count is not None for c in code), 'Hay celdas sin ejecutar'
errors=[o for c in code for o in c.outputs if o.output_type=='error']
assert not errors, errors
counts=[c.execution_count for c in code]
assert counts==list(range(1,len(code)+1)), counts
base=pd.read_csv(root/'resultados.csv')
assert len(base)==20 and base.groupby('k').size().to_dict()=={3:10,5:10}
assert not base[['abstuvo','generador']].isna().any().any()
assert base.generador.eq('ollama:gemma3:4b').all()
answers=json.loads((root/'evidencias/respuestas_baseline.json').read_text())
assert len(answers)==20 and all(x['salida'] and x['salida']['answer'].strip() for x in answers)
assert all(not x['salida']['generator'].startswith('modo inspección') for x in answers)
ext=pd.read_csv(root/'resultados_extension.csv')
assert len(ext)==20 and ext.groupby('k').size().to_dict()=={3:10,5:10}
assert set(zip(base.id,base.k))==set(zip(ext.id,ext.k))
summary=json.loads((root/'evidencias/resumen_baseline.json').read_text())
for k,g in base.groupby('k'):
    r=g[g.respondible]
    assert abs(r.hit.astype(float).mean()-summary[str(k)]['hit_rate'])<1e-9
    assert abs(r.reciprocal_rank.mean()-summary[str(k)]['mrr'])<1e-9
state=json.loads((root/'evidencias/estado_entrega.json').read_text())
result={
 'fecha_utc':datetime.now(timezone.utc).isoformat(),
 'notebook_sha256':hashlib.sha256(nbpath.read_bytes()).hexdigest(),
 'celdas_codigo':len(code),'celdas_ejecutadas':len(counts),'errores':len(errors),
 'filas_baseline':len(base),'respuestas_reales':len(answers),'filas_extension':len(ext),
 'generador':base.generador.unique().tolist(),
 'pendientes_de_entrega':[k for k,v in state.items() if not v],
 'metricas':pd.read_csv(root/'evidencias/tabla_metricas_baseline.csv').to_dict('records')
}
(root/'evidencias/verificacion_ejecucion.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
