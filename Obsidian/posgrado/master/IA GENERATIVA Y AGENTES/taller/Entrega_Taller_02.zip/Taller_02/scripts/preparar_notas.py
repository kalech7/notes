"""Copia las notas elegidas sin modificar los originales y documenta su paginación."""
from pathlib import Path
import hashlib
import json
import textwrap
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
ORIGEN = Path('/home/alech/IdeaProjects/notes/Obsidian/posgrado/master/IA GENERATIVA Y AGENTES')
SECCIONES = ('07 Embeddings y recuperación', '08 RAG fragmentación y recuperación',
             '09 Evaluación de RAG y patrones avanzados')

def preparar():
    destino, pdfs = ROOT / 'corpus', ROOT / 'data' / 'notas_paginadas'
    destino.mkdir(exist_ok=True)
    pdfs.mkdir(parents=True, exist_ok=True)
    fuente = Path('/usr/share/fonts/dejavu-sans-mono-fonts/DejaVuSansMono.ttf')
    if not fuente.exists():
        candidatos = list(Path('/usr/share/fonts').rglob('DejaVuSansMono.ttf'))
        fuente = candidatos[0] if candidatos else None
    if fuente:
        pdfmetrics.registerFont(TTFont('NotasMono', str(fuente)))
    font = 'NotasMono' if fuente else 'Courier'
    registros = []
    for seccion in SECCIONES:
        for source in sorted((ORIGEN / seccion).glob('*.md')):
            raw = source.read_bytes()
            target = destino / source.name
            if target.exists() and target.read_bytes() != raw:
                raise ValueError(f'Ya existe una copia distinta: {target}; no se sobrescribe.')
            target.write_bytes(raw)
            # PDF de transcripción: conserva Markdown y fórmulas literalmente.
            # A4, márgenes 2 cm, 9 puntos monoespaciados, interlineado 12.
            pdf = pdfs / (source.stem + '.pdf')
            c = canvas.Canvas(str(pdf), pagesize=A4)
            c.setTitle(source.stem)
            width, height = A4
            margin, size, leading = 56.7, 9, 12
            chars = int((width - 2 * margin) / pdfmetrics.stringWidth('M', font, size))
            lines = []
            for line in raw.decode('utf-8').expandtabs(4).splitlines():
                lines.extend(textwrap.wrap(line, width=chars, replace_whitespace=False,
                    drop_whitespace=False, break_long_words=True, break_on_hyphens=False) or [''])
            y, page = height-margin, 1
            c.setFont(font,size)
            for line in lines:
                if y < margin:
                    c.setFont('Helvetica',8)
                    c.drawRightString(width-margin,30,str(page))
                    c.showPage(); c.setFont(font,size); y=height-margin; page+=1
                c.drawString(margin,y,line); y-=leading
            c.setFont('Helvetica',8);c.drawRightString(width-margin,30,str(page));c.save()
            registros.append({'documento': source.name, 'origen': str(source),
                'sha256': hashlib.sha256(raw).hexdigest(), 'palabras': len(raw.decode().split()),
                'idioma': 'es', 'pdf_exportado': str(pdf.relative_to(ROOT)),
                'paginas_exportadas': len(PdfReader(pdf).pages)})
    manifest = {'origen':str(ORIGEN),'criterio':'Notas 28–49: embeddings, RAG y evaluación.',
        'formato_indexado':'Markdown original sin modificaciones',
        'paginacion':'Transcripción A4, márgenes 2 cm, fuente monoespaciada 9 pt, interlineado 12 pt. No son páginas originales.',
        'limitacion':'Exportación textual: imágenes y diagramas no se interpretan; fórmulas y enlaces conservan su sintaxis Markdown.',
        'documentos':registros}
    (ROOT/'corpus_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    return manifest

if __name__ == '__main__':
    m=preparar()
    print(len(m['documentos']),'notas;',sum(d['paginas_exportadas'] for d in m['documentos']),
          'páginas exportadas;',sum(d['palabras'] for d in m['documentos']),'palabras')
