"""Construye el notebook pedagógico; no ejecuta servicios ni genera métricas."""
from pathlib import Path
import textwrap
import nbformat as nbf

cells=[]
def md(s): cells.append(nbf.v4.new_markdown_cell(textwrap.dedent(s).strip()))
def code(s): cells.append(nbf.v4.new_code_cell(textwrap.dedent(s).strip()))

md(r'''
# Taller 02 — RAG y búsqueda vectorial

Ejecuta las celdas en orden. Cada parte muestra el paso, el resultado y la evidencia guardada.
El análisis completo y los fragmentos íntegros están en `Informe_Taller_02.pdf`.
''')
md(r'''
## Preparación

Usa el kernel **Taller 02 RAG**. La siguiente celda configura corpus, fragmentación (512 tokens,
102 de solapamiento), rutas de evidencias y servicios locales. La Parte 0 usa MiniLM;
el baseline usa BGE-M3 en CUDA, Qdrant persistente y Ollama.
''')
code('''
from pathlib import Path
from contextlib import redirect_stdout, redirect_stderr
from datetime import datetime, timezone
import hashlib
import importlib
import io
import json
import os
import re
import sys
import urllib.request

import numpy as np
import pandas as pd
from IPython.display import display, Markdown
from dotenv import load_dotenv
from pypdf import PdfReader

ROOT = Path.cwd()
assert (ROOT / "rag_pipeline.py").exists(), "Abre el notebook desde la carpeta del laboratorio."
load_dotenv(ROOT / ".env", override=False)
EVIDENCIAS = ROOT / "evidencias"
DATA = ROOT / "data"
EVIDENCIAS.mkdir(exist_ok=True)
DATA.mkdir(exist_ok=True)

CORPUS_DIR = Path(os.getenv("CORPUS_DIR", str(ROOT / "corpus"))).expanduser().resolve()
IDIOMA = os.getenv("CORPUS_IDIOMA", "es")
CHUNK_TOKENS = 512
OVERLAP_TOKENS = 102  # aproximadamente un quinto del fragmento
EJECUTAR_BASELINE = True
GENERAR_RESPUESTAS = True
QDRANT_BASELINE = os.getenv("QDRANT_URL", "http://localhost:6333")
EMBEDDING_DEVICE_BASELINE = os.getenv("EMBEDDING_DEVICE", "cuda")
OLLAMA_LOCAL = os.getenv("OLLAMA_URL", "http://localhost:11434")
MODELO_GENERACION = os.getenv("GENERATION_MODEL", "gemma3:4b").strip()
GOLDEN_PATH = ROOT / "golden_set.json"

# Fechas transcritas del anexo del taller; no son una nueva verificación web.
FILA_LOCAL = {"id": "embed_notebook_s2", "model":
    "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
    "max_seq_tokens": 128, "verified_at": "2026-08-27", "dimension": 384}
FILA_BASELINE = {"id": "embed_local_multilingue", "model": "BAAI/bge-m3",
    "max_seq_tokens": 8192, "verified_at": "2026-08-27", "dimension": 1024}

# Permite JSON estricto: una métrica no medida se guarda como null, nunca como cero.
def guardar_json(path, value):
    def limpio(x):
        if isinstance(x, dict): return {str(k): limpio(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)): return [limpio(v) for v in x]
        if isinstance(x, np.generic): return limpio(x.item())
        if isinstance(x, float) and not np.isfinite(x): return None
        if isinstance(x, Path): return str(x)
        return x
    Path(path).write_text(json.dumps(limpio(value), ensure_ascii=False,
                                    indent=2, allow_nan=False) + "\\n", encoding="utf-8")

def capturar(funcion, archivo):
    buffer = io.StringIO()
    with redirect_stdout(buffer), redirect_stderr(buffer):
        resultado = funcion()
    texto = buffer.getvalue()
    (EVIDENCIAS / archivo).write_text(texto, encoding="utf-8")
    print(texto)
    return resultado

print("Python:", sys.version.split()[0])
print("Corpus:", CORPUS_DIR, "| idioma declarado:", IDIOMA)
print("Fragmentación baseline:", CHUNK_TOKENS, "tokens; solapamiento:", OVERLAP_TOKENS)
''')
md(r'''
## Parte 0.a — PDF sin texto

Ingestamos `ejemplos/` y comprobamos que el PDF escaneado se rechaza: no tiene texto útil.
La salida cruda queda en `evidencias/parte0a_ingesta.txt`.
''')
code('''
os.environ["EMBEDDING_BACKEND"] = "local"
os.environ["EMBEDDING_MODEL"] = FILA_LOCAL["model"]
os.environ["QDRANT_URL"] = ":memory:"
import rag_pipeline as rp
rp = importlib.reload(rp)
import ingestion

p0 = rp.RagPipeline(collection="taller02_parte0")
print("Modelo:", rp.EMBEDDING_MODEL, "| tope leído:", p0.max_seq_tokens)
chunks0 = capturar(lambda: p0.ingest(ROOT / "ejemplos"), "parte0a_ingesta.txt")
p0.index(chunks0)
print("Fragmentos indexados:", len(chunks0))
''')
code('''
escaneado = ingestion.read_document(ROOT / "ejemplos/instructivo_escaneado.pdf")
display(pd.DataFrame([{
    "documento": escaneado.name, "paginas": escaneado.pages,
    "caracteres_utiles": escaneado.useful_chars,
    "rechazado": escaneado.parece_escaneado,
    "texto_extraido": repr(escaneado.text)
}]))
assert escaneado.useful_chars == 0
assert not any(c.document == escaneado.name for c in chunks0)
''')
md(r'''
**Qué evita la ingesta:** `load_corpus` comprueba caracteres útiles antes de indexar.
Sin el filtro por documento, el PDF produciría marcadores de página sin texto; el filtro
adicional por fragmento también impediría indexarlos en este ejemplo.
''')
md(r'''
## Parte 0.b — Truncamiento

MiniLM admite 128 tokens. Pedimos bloques de 900 para ver el aviso del ingestor;
luego contamos un texto largo y comparamos su vector con el del prefijo que sí recibe el modelo.
''')
code('''
chunks_demasiado_largos = capturar(
    lambda: p0.ingest(ROOT / "ejemplos", chunk_tokens=900, overlap_tokens=180),
    "parte0b_aviso.txt"
)
# Solicitar 900 no implica que estos tres archivos cortos tengan 900 tokens.
# Por eso el experimento de truncamiento usa un texto largo construido aparte.
''')
code('''
frase = "El estudiante revisa el reglamento y conserva evidencia de cada trámite académico."
texto_largo = " ".join((frase.split() * 100)[:900])
tok0 = p0.encoder.tokenizer
tope0 = p0.max_seq_tokens
# Se cuentan todos los tokens; esta secuencia larga nunca se envía al modelo.
# verbose=False evita el aviso genérico del tokenizador, que aquí no indica un fallo.
ids_sin_especiales = tok0(texto_largo, add_special_tokens=False,
                           truncation=False, verbose=False)["input_ids"]
especiales = tok0.num_special_tokens_to_add(pair=False)
texto_recortado = tok0.decode(ids_sin_especiales[:tope0 - especiales], skip_special_tokens=True)

# Comparamos primero lo que efectivamente recibe el modelo: evita errores de decode/reencode.
entrada_larga = tok0(texto_largo, truncation=True, max_length=tope0)["input_ids"]
entrada_corta = tok0(texto_recortado, truncation=True, max_length=tope0)["input_ids"]
assert entrada_larga == entrada_corta, "La decodificación cambió tokens: revisar el corte."
v_entero, v_recorte = p0.encoder.encode([texto_largo, texto_recortado])
coseno = float(np.dot(v_entero, v_recorte) /
               (np.linalg.norm(v_entero) * np.linalg.norm(v_recorte)))
medicion0b = {
    "palabras": len(texto_largo.split()),
    "tokens_texto_sin_especiales": len(ids_sin_especiales),
    "tokens_texto_con_especiales": len(ids_sin_especiales) + especiales,
    "tope_modelo": tope0, "tokens_especiales": especiales,
    "tokens_que_ve_el_modelo": len(entrada_larga), "coseno": coseno
}
guardar_json(EVIDENCIAS / "parte0b_truncamiento.json", medicion0b)
display(pd.DataFrame([medicion0b]))
assert np.isclose(coseno, 1.0, atol=1e-5)
''')
md(r'''
**Resultado:** un coseno cercano a 1 indica que ambos vectores se calcularon con el mismo prefijo;
no implica que el texto completo haya sido representado. El baseline usa 512 tokens y 102 de
solapamiento para mantener pasajes próximos sin llenar los 8192 tokens permitidos por BGE-M3.
''')
md(r'''
## Parte 0.c — Vecinos sin respuesta

Consultamos algo ausente y algo presente solo en el PDF escaneado. Qdrant devuelve vecinos
en ambos casos; sus puntajes no prueban que exista una respuesta.
''')
code('''
preguntas0c = [
    "¿cuál es la política de mascotas?",
    "¿qué exige el instructivo de prácticas de campo sobre el seguro de accidentes?"
]
vecinos0c = []
for pregunta in preguntas0c:
    hits = p0.retrieve(pregunta, top_k=3)
    vecinos0c.append({"pregunta": pregunta, "hits": hits})
    print("\\nPREGUNTA:", pregunta)
    for posicion, h in enumerate(hits, 1):
        print(f"{posicion}. score={h['score']:.6f} | {h['document']} | {h['chunk_id']}")
        print(h["text"], "\\n")
guardar_json(EVIDENCIAS / "parte0c_vecinos.json", vecinos0c)
''')
md(r'''
**Conclusión:** Hit Rate evalúa recuperación en preguntas respondibles. Las dos preguntas
sin evidencia se evalúan por abstención, no como fallos de recuperación.
''')
md(r'''
## Corpus

Usamos 22 notas propias en español, indexadas desde Markdown. Sus exportaciones textuales
suman 70 páginas A4. El manifiesto registra origen y hashes.
''')
code('''
# Las copias y exportaciones ya vienen preparadas. Para reconstruirlas si faltan:
if not (ROOT / "corpus_manifest.json").exists():
    import runpy
    runpy.run_path(str(ROOT / "scripts/preparar_notas.py"), run_name="__main__")
''')
md(r'''
## Parte 1.1 — Auditoría

Contamos documentos, páginas y caracteres útiles; verificamos los hashes y detectamos
archivos sin texto. La tabla siguiente resume la ingesta.
''')
code('''
manifest_path = ROOT / "corpus_manifest.json"
manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
exportaciones = {d["documento"]: d for d in manifest.get("documentos", [])}
archivos_corpus = sorted(p for p in CORPUS_DIR.glob("*")
    if p.suffix.lower() in {".pdf", ".md", ".txt"} and p.name != "README.md")
documentos = {}
inventario = []
for archivo in archivos_corpus:
    try:
        doc = ingestion.read_document(archivo)
        documentos[doc.name] = doc
        textos_paginas = [p.extract_text() or "" for p in PdfReader(archivo).pages] \
            if archivo.suffix.lower() == ".pdf" else [doc.text]
        sospechosas = [i for i, texto in enumerate(textos_paginas, 1)
                      if ingestion.caracteres_utiles(texto) < 20]
        inventario.append({"documento": doc.name, "paginas_pdf": doc.pages
            if archivo.suffix.lower() == ".pdf" else 0,
            "paginas_exportadas": (len(PdfReader(ROOT / exportaciones[doc.name]["pdf_exportado"]).pages)
                if doc.name in exportaciones and hashlib.sha256(archivo.read_bytes()).hexdigest()
                   == exportaciones[doc.name]["sha256"] else 0),
            "caracteres_utiles": doc.useful_chars, "rechazado": doc.parece_escaneado,
            "paginas_con_poco_texto": sospechosas,
            "sha256": hashlib.sha256(archivo.read_bytes()).hexdigest(), "error": None})
    except Exception as exc:
        inventario.append({"documento": archivo.name, "paginas_pdf": 0, "paginas_exportadas": 0,
            "caracteres_utiles": 0, "rechazado": True,
            "paginas_con_poco_texto": [], "sha256": None, "error": type(exc).__name__})

guardar_json(EVIDENCIAS / "inventario_corpus.json", inventario)
inventario_df = pd.DataFrame(inventario)
display(inventario_df)
aceptados = [d for d in inventario if not d["rechazado"]]
paginas_originales = sum(d["paginas_pdf"] for d in inventario)
paginas_exportadas = sum(d["paginas_exportadas"] for d in inventario)
paginas_totales = paginas_originales + paginas_exportadas
CORPUS_LISTO = len(aceptados) >= 5 and paginas_totales >= 50
print("Documentos:", len(inventario), "| aceptados:", len(aceptados), "| páginas originales:", paginas_originales,
      "| páginas de exportaciones Markdown:", paginas_exportadas)
print("Corpus apto para continuar:", CORPUS_LISTO)
if not CORPUS_LISTO:
    print("PENDIENTE: configura CORPUS_DIR con tus documentos; no se usará ejemplos/ como corpus real.")
''')
code('''
# Vista para revisar la calidad de extracción sin imprimir los documentos enteros.
for nombre, doc in list(documentos.items())[:5]:
    print("\\n---", nombre, "---")
    print(doc.text[:900])

# Completa observaciones después de comparar con las páginas originales.
# Ejemplo: {"documento.pdf": "p. 8: la tabla se lee por columnas; ..."}
OBSERVACIONES_INGESTA = {
    "corpus_markdown": "UTF-8 íntegro; se preservan títulos, tablas en texto, LaTeX y enlaces de Obsidian.",
    "limitaciones": "Las imágenes referenciadas no se leen; no se renderiza LaTeX ni Mermaid. El frontmatter y los enlaces pueden añadir ruido al embedding.",
    "paginacion": "70 páginas de exportación textual A4 de 22 notas, no páginas originales de los Markdown.",
    "parte0": "El PDF escaneado de ejemplos tiene cero caracteres útiles y se rechaza."
}
guardar_json(EVIDENCIAS / "observaciones_ingesta.json", OBSERVACIONES_INGESTA)
''')
md(r'''
## Partes 1.2–1.3 — Fragmentos e índice

Fragmentamos en tokens de BGE-M3, calculamos embeddings en la GPU y los guardamos en Qdrant.
Comprobamos que ningún fragmento medido supera el límite del modelo.
''')
code('''
def consultar_json(url):
    with urllib.request.urlopen(url, timeout=5) as r:
        return json.loads(r.read())

import torch
estado_servicios = {"gpu": {"disponible": torch.cuda.is_available(),
    "error": "CUDA no disponible; instala PyTorch con CUDA",
    "dispositivo": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None}}
for nombre, url in {
    "qdrant": QDRANT_BASELINE.rstrip("/") + "/collections",
    "ollama": OLLAMA_LOCAL.rstrip("/") + "/api/tags"
}.items():
    try:
        estado_servicios[nombre] = {"disponible": True, "datos": consultar_json(url)}
    except Exception as exc:
        estado_servicios[nombre] = {"disponible": False, "error": type(exc).__name__}

for nombre, estado in estado_servicios.items():
    print(nombre, "disponible" if estado["disponible"] else "PENDIENTE: " + estado["error"])

if not MODELO_GENERACION:
    fila_generador = rp.fila_de_la_tabla("models", "open_weight_pequeno")
    MODELO_GENERACION = fila_generador.get("model", "")
else:
    fila_generador = rp.fila_de_la_tabla("models", "open_weight_pequeno")
modelos_instalados = [m["name"] for m in estado_servicios.get("ollama", {}).get("datos", {}).get("models", [])]
print("Modelos Ollama instalados:", modelos_instalados)
modelo_presente = any(m == MODELO_GENERACION or m == MODELO_GENERACION + ":latest"
                      for m in modelos_instalados) if MODELO_GENERACION else False
GEN_LISTO = GENERAR_RESPUESTAS and modelo_presente
if not MODELO_GENERACION:
    print("PENDIENTE: GENERATION_MODEL; usa el modelo de la fila open_weight_pequeno del curso.")
BASELINE_LISTO = (EJECUTAR_BASELINE and CORPUS_LISTO and QDRANT_BASELINE != ":memory:"
    and estado_servicios["gpu"]["disponible"] and estado_servicios["qdrant"]["disponible"])
''')
code('''
# Configuración de la ruta obligatoria elegida por el usuario.
os.environ.update({"EMBEDDING_BACKEND": "local", "EMBEDDING_MODEL": FILA_BASELINE["model"],
    "QDRANT_URL": QDRANT_BASELINE, "EMBEDDING_DEVICE": EMBEDDING_DEVICE_BASELINE,
    "GENERATION_BACKEND": "ollama", "OLLAMA_URL": OLLAMA_LOCAL})
if MODELO_GENERACION:
    os.environ["GENERATION_MODEL"] = MODELO_GENERACION
rp = importlib.reload(rp)
import evaluation
# El evaluador mantiene su clase importada; recargamos después de reconfigurar.
evaluation = importlib.reload(evaluation)

configuracion = {"embeddings": FILA_BASELINE, "corpus_idioma": IDIOMA,
    "embedding_backend": "local", "embedding_device": EMBEDDING_DEVICE_BASELINE,
    "embedding_dtype": os.getenv("EMBEDDING_DTYPE", "auto"),
    "embedding_batch_size": int(os.getenv("EMBEDDING_BATCH_SIZE", "4")),
    "chunk_tokens": CHUNK_TOKENS, "overlap_tokens": OVERLAP_TOKENS,
    "corpus": inventario, "generacion_backend": "ollama",
    "generacion_modelo": MODELO_GENERACION or None,
    "generacion_fila": fila_generador or None,
    "generacion_fila_pendiente": not bool(fila_generador),
    "origen_verified_at": "anexo del PDF del taller"}
huella = hashlib.sha256(json.dumps(configuracion, sort_keys=True).encode()).hexdigest()[:12]
COLECCION = "taller02_baseline_" + huella
guardar_json(EVIDENCIAS / "configuracion.json", configuracion)

pipeline = None
chunks = []
if BASELINE_LISTO:
    # Liberar MiniLM antes de cargar BGE-M3 en la GPU de 4 GB.
    if "p0" in globals():
        del p0
    import gc
    gc.collect()
    torch.cuda.empty_cache()
    pipeline = rp.RagPipeline(collection=COLECCION)
    print("Embeddings:", pipeline.encoder.device, pipeline.encoder.dtype,
          "| lote:", pipeline.encoder.batch_size)
    assert pipeline.max_seq_tokens == FILA_BASELINE["max_seq_tokens"]
    especiales = pipeline.encoder.tokenizer.num_special_tokens_to_add(pair=False)
    assert 0 <= OVERLAP_TOKENS < CHUNK_TOKENS <= pipeline.max_seq_tokens - especiales
    chunks = capturar(lambda: pipeline.ingest(CORPUS_DIR,
        chunk_tokens=CHUNK_TOKENS, overlap_tokens=OVERLAP_TOKENS), "parte1_ingesta.txt")
    assert chunks, "La ingesta no produjo fragmentos."
    # Verificamos también decode/reencode, no solo el corte teórico en IDs.
    tokens_reales = [len(pipeline.encoder.tokenizer(c.text)["input_ids"]) for c in chunks]
    assert max(tokens_reales) <= pipeline.max_seq_tokens
    ingestion.write_chunks_jsonl(chunks, DATA / "chunks_baseline.jsonl")
    pipeline.index(chunks)
    print("Colección:", COLECCION, "| fragmentos:", len(chunks))
    print("Máximo de tokens observado (con especiales):", max(tokens_reales))
else:
    print("PENDIENTE: corpus y/o CUDA y/o contenedor Qdrant. No se creó un índice alternativo.")
''')
md(r'''
## Parte 2.a — Golden set

Validamos diez preguntas contra el corpus: cuatro simples, tres que combinan pasajes,
dos negativas y una adversarial respondible. La evidencia se anota por documento y frase,
para conservar la referencia aunque cambien los identificadores de fragmento.
''')
code('''
if not GOLDEN_PATH.exists():
    plantilla = json.loads((ROOT / "golden_set_plantilla.json").read_text(encoding="utf-8"))
    guardar_json(GOLDEN_PATH, plantilla)

golden = evaluation.load_golden_set(GOLDEN_PATH)
# Estos metadatos no sustituyen una revisión humana.
METADATOS_GOLDEN = {"version": "1.0", "responsable": "Anotación inicial del asistente sobre notas del usuario; revisión final del usuario pendiente",
    "idioma": IDIOMA, "corpus_huella": huella,
    "sha256_golden": hashlib.sha256(GOLDEN_PATH.read_bytes()).hexdigest(),
    "adversarial": "respondible: ignorar la instrucción inyectada y usar las fuentes",
    "negativas": "ausencia de evidencia revisada en todo el corpus, no solo en el top-k"}
guardar_json(EVIDENCIAS / "golden_metadata.json", METADATOS_GOLDEN)
print("Editar:", GOLDEN_PATH)
display(pd.DataFrame(golden)[["id", "tipo", "pregunta", "documentos_fuente"]])
''')
code('''
def validar_golden(items, docs):
    errores = []
    normalizar = rp._normalizar_texto
    if len(items) != 10: errores.append("Deben existir exactamente diez preguntas.")
    if len({str(i.get("id")) for i in items}) != len(items): errores.append("Hay IDs duplicados.")
    if sum(not i.get("documentos_fuente") for i in items) < 2:
        errores.append("Se requieren al menos dos negativas.")
    for tipo in ("simple", "multi-chunk", "negativo", "adversarial"):
        if not any(i.get("tipo") == tipo for i in items): errores.append("Falta tipo: " + tipo)
    for item in items:
        etiqueta = str(item.get("id"))
        for campo in ("pregunta", "respuesta_esperada", "criterio_exito"):
            valor = item.get(campo, "").strip()
            if not valor or "REEMPLAZAR" in valor:
                errores.append(f"{etiqueta}: completar {campo}.")
        fuentes = item.get("documentos_fuente", [])
        if item.get("tipo") != "negativo" and not fuentes:
            errores.append(f"{etiqueta}: falta fuente para la decisión respondible elegida.")
        if item.get("tipo") == "negativo" and fuentes:
            errores.append(f"{etiqueta}: una negativa no lleva fuente.")
        if not fuentes and item.get("respuesta_esperada") != rp.ABSTENCION:
            errores.append(f"{etiqueta}: usa ABSTENCION como respuesta esperada negativa.")
        for fuente in fuentes:
            if fuente not in docs: errores.append(f"{etiqueta}: fuente inexistente: {fuente}")
        frase = item.get("fragmento_esperado", "").strip()
        if fuentes and frase and not any(
            normalizar(frase) in normalizar(docs[f].text) for f in fuentes if f in docs
        ): errores.append(f"{etiqueta}: fragmento_esperado no aparece en la fuente.")
        if item.get("tipo") == "multi-chunk":
            evidencias = item.get("evidencias_esperadas", [])
            if len(evidencias) < 2:
                errores.append(f"{etiqueta}: añade al menos dos evidencias_esperadas con documento y frase.")
            for ev in evidencias:
                fuente, cita = ev.get("documento"), ev.get("frase", "")
                if fuente not in fuentes or not cita.strip() or (
                    fuente in docs and normalizar(cita) not in normalizar(docs[fuente].text)):
                    errores.append(f"{etiqueta}: evidencia multi-fragmento inválida.")
    return errores

# Ejemplo de campo adicional, no es una anotación real de tu corpus:
# "evidencias_esperadas": [
#     {"documento": "manual.pdf", "frase": "frase literal breve A"},
#     {"documento": "reglamento.pdf", "frase": "frase literal breve B"}
# ]
errores_golden = validar_golden(golden, documentos)
GOLDEN_LISTO = not errores_golden
print("Golden válido:", GOLDEN_LISTO)
for error in errores_golden: print("PENDIENTE:", error)
''')
md(r'''
## Partes 1.4–1.5 — Recuperación y respuesta

Mostramos los cinco vecinos de tres preguntas y la respuesta local de Ollama.
El prompt pide usar solo el contexto y permite una frase fija de abstención.
''')
code('''
class PipelineConEvidencias:
    def __init__(self, base):
        self.base = base
        self.retrieval_cache = {}
        self.answer_cache = {}
        self.llamadas_generacion = 0

    def retrieve(self, question, top_k=5):
        key = (question, top_k)
        if key not in self.retrieval_cache:
            self.retrieval_cache[key] = self.base.retrieve(question, top_k=top_k)
        return self.retrieval_cache[key]

    def answer(self, question, top_k=5):
        key = (question, top_k)
        if key not in self.answer_cache:
            contexts = self.retrieve(question, top_k)
            prompt = self.base.build_prompt(question, contexts)
            self.llamadas_generacion += 1
            texto = self.base.generate(prompt)
            inspeccion = self.base.ultima_generacion.startswith("modo inspección")
            self.answer_cache[key] = {"question": question, "contexts": contexts,
                "prompt": prompt, "answer": texto,
                "abstained": None if inspeccion else rp.se_abstuvo(texto),
                "generator": self.base.ultima_generacion}
        return self.answer_cache[key]

    def exportar(self, items, ks):
        return [{"id": item["id"], "k": k, "pregunta": item["pregunta"],
                 "hits": self.retrieval_cache.get((item["pregunta"], k), []),
                 "salida": self.answer_cache.get((item["pregunta"], k))}
                for k in ks for item in items]

baseline = PipelineConEvidencias(pipeline) if pipeline else None
if baseline and GOLDEN_LISTO:
    pruebas = [item for item in golden if item["documentos_fuente"]][:3]
    for item in pruebas:
        print("\\nPREGUNTA:", item["pregunta"])
        display(pd.DataFrame(baseline.retrieve(item["pregunta"], top_k=5)))
        if GEN_LISTO:
            salida = baseline.answer(item["pregunta"], top_k=5)
            print("GENERADOR:", salida["generator"], "\\nRESPUESTA:", salida["answer"])
        else:
            print("PENDIENTE generación. Prompt para inspeccionar:")
            print(pipeline.build_prompt(item["pregunta"], baseline.retrieve(item["pregunta"], 5)))
    guardar_json(EVIDENCIAS / "parte1_top5.json", baseline.exportar(pruebas, [5]))
else:
    print("PENDIENTE: índice y golden set validado para mostrar tres top-5 reales.")
''')
md(r'''
## Parte 2.b — Métricas

Hit Rate mide si llegó **alguna** evidencia; MRR mide el puesto del primer acierto.
Se calculan sobre las ocho respondibles. Las dos negativas aportan a abstención correcta;
la abstención en respondibles cuenta como indebida. Se escriben 20 filas crudas.
''')
code('''
reportes = {}
resultados = None
if baseline and GOLDEN_LISTO:
    for k in (3, 5):
        reportes[k] = evaluation.evaluate_retrieval(golden, baseline, k=k, generar=GEN_LISTO)
    filas = [r for k in (3, 5) for r in reportes[k]["rows"]]
    assert len(filas) == 20
    evaluation.escribir_csv(filas, ROOT / "resultados.csv", FILA_BASELINE["model"])
    guardar_json(EVIDENCIAS / "resumen_baseline.json", reportes)
    guardar_json(EVIDENCIAS / "respuestas_baseline.json", baseline.exportar(golden, [3, 5]))
    print("CSV crudo:", ROOT / "resultados.csv")
    print("Intentos reales de generación:", baseline.llamadas_generacion, "(máximo 20)")
else:
    print("PENDIENTE: no se genera resultados.csv con datos simulados ni con la plantilla incompleta.")
''')
code('''
def resumen_desde_csv(path):
    # Una celda vacía conserva el significado de «no medido».
    df = pd.read_csv(path)
    for col in ("respondible", "hit", "abstuvo"):
        df[col] = df[col].map(lambda x: pd.NA if pd.isna(x)
            else {"true": True, "false": False}[str(x).lower()]).astype("boolean")
    resumen = []
    for k, grupo in df.groupby("k"):
        resp = grupo[grupo["respondible"]]
        neg = grupo[~grupo["respondible"]]
        resumen.append({"k": int(k), "respondibles": len(resp), "negativas": len(neg),
            "Hit Rate": resp["hit"].mean(), "MRR": resp["reciprocal_rank"].mean(),
            "abstención correcta": neg["abstuvo"].mean(),
            "abstención indebida": resp["abstuvo"].mean(),
            "negativas con generación": int(neg["abstuvo"].notna().sum()),
            "respondibles con generación": int(resp["abstuvo"].notna().sum())})
    return df, pd.DataFrame(resumen)

tabla_baseline = None
if reportes:
    resultados, tabla_baseline = resumen_desde_csv(ROOT / "resultados.csv")
    display(tabla_baseline)
    tabla_baseline.to_csv(EVIDENCIAS / "tabla_metricas_baseline.csv", index=False)
    for _, fila in tabla_baseline.iterrows():
        rep = reportes[int(fila["k"])]
        assert np.isclose(fila["Hit Rate"], rep["hit_rate"])
        assert np.isclose(fila["MRR"], rep["mrr"])
    print("Tabla reconstruida desde el CSV y contrastada con el evaluador.")
else:
    print("PENDIENTE: tabla de métricas medida.")
''')
md(r'''
### Cobertura de preguntas con varias fuentes

Un acierto no garantiza que llegaron todos los pasajes necesarios. Medimos también
cuántas anclas del golden aparecen en el top-k de cada pregunta multi-fragmento.
''')
code('''
def cobertura_evidencias(item, hits):
    evidencias = item.get("evidencias_esperadas", [])
    if not evidencias: return None
    encontrados = [any(h["document"] == ev["documento"] and
        rp._normalizar_texto(ev["frase"]) in rp._normalizar_texto(h["text"])
        for h in hits) for ev in evidencias]
    return sum(encontrados) / len(encontrados)

coberturas = []
if baseline and GOLDEN_LISTO:
    for k in (3, 5):
        for item in golden:
            if item.get("evidencias_esperadas"):
                coberturas.append({"id": item["id"], "k": k,
                    "cobertura": cobertura_evidencias(item, baseline.retrieve(item["pregunta"], k))})
    display(pd.DataFrame(coberturas))
    guardar_json(EVIDENCIAS / "cobertura_multi_fragmento.json", coberturas)
''')
md(r'''
## Parte 2.c — Tres casos difíciles

Revisamos las tres preguntas peor resueltas usando la ingesta, los vecinos y la respuesta.
La celda registra una hipótesis inicial; la revisión final está en `REVISION_FINAL.md`.
''')
code('''
casos_dificiles = []
if reportes:
    def severidad(r):
        abstencion_erronea = ((not r["respondible"] and r["abstuvo"] is False) or
                              (r["respondible"] and r["abstuvo"] is True))
        return (int(abstencion_erronea), int(r["respondible"] and not r["hit"]),
                1 - (r["reciprocal_rank"] or 0))
    por_id = {item["id"]: item for item in golden}
    for fila in sorted(reportes[5]["rows"], key=severidad, reverse=True)[:3]:
        item = por_id[fila["id"]]
        hits = baseline.retrieve(item["pregunta"], 5)
        salida = baseline.answer_cache.get((item["pregunta"], 5))
        fuentes = item["documentos_fuente"]
        if any(documentos[f].parece_escaneado for f in fuentes):
            hipotesis = "Ingesta: fuente rechazada; revisar texto extraíble y registro de ingesta."
        elif fila["respondible"] and not fila["hit"]:
            existe_en_chunks = any(evaluation.acierta({"document": c.document, "text": c.text}, item)
                                   for c in chunks)
            hipotesis = ("Recuperación: existe un fragmento anotado, pero no entró en top-5."
                         if existe_en_chunks else
                         "Fragmentación o anotación: la evidencia no aparece completa en ningún fragmento.")
        elif fila["abstuvo"] is None:
            hipotesis = "Generación sin medir; no puede diagnosticarse su abstención."
        elif (not fila["respondible"] and not fila["abstuvo"]) or (fila["respondible"] and fila["abstuvo"]):
            hipotesis = "Revisar prompt, suficiencia del contexto y generación antes de atribuir la causa."
        else:
            hipotesis = "Revisar cobertura, precisión y citas: no hay fallo demostrado por estas métricas."
        caso = {"id": item["id"], "pregunta": item["pregunta"], "metricas": fila,
            "ingesta_fuentes": [d for d in inventario if d["documento"] in fuentes],
            "log_ingesta": "evidencias/parte1_ingesta.txt", "hits": hits,
            "respuesta_completa": salida["answer"] if salida else None,
            "hipotesis": hipotesis, "diagnostico_revisado": "PENDIENTE: revisión humana"}
        casos_dificiles.append(caso)
        print("\\nCASO", caso["id"], caso["pregunta"], "\\n", hipotesis)
        display(pd.DataFrame(hits))
        print("Respuesta:", caso["respuesta_completa"])
    guardar_json(EVIDENCIAS / "tres_casos_dificiles.json", casos_dificiles)
else:
    print("PENDIENTE: ejecutar el baseline antes de elegir y explicar fallos.")
''')
md(r'''
## Parte 3 — BM25 + RRF

Registramos la hipótesis antes de medir. BM25 ordena por términos; BGE-M3, por similitud;
RRF fusiona posiciones. Comparamos ambos métodos con el mismo golden set y los mismos cortes.
''')
code('''
HIPOTESIS_EXTENSION = ""  # Puedes escribir una hipótesis específica tras revisar los tres casos.
EJECUTAR_COMPARACION_EXPLORATORIA = False
HIPOTESIS_JUSTIFICADA = False
if reportes:
    problemas_ranking = [r["id"] for r in reportes[5]["rows"]
        if r["respondible"] and (not r["hit"] or (r["posicion"] or 99) > 1)]
    if problemas_ranking and not HIPOTESIS_EXTENSION:
        HIPOTESIS_EXTENSION = (
            f"El baseline pierde evidencia o la recupera tarde en {problemas_ranking}. "
            "Probaré si coincidencias léxicas de BM25 aportan candidatos que el ranking denso "
            "no prioriza. Espero un aumento de Hit Rate o MRR, sin asumir que ocurrirá. "
            "Debo contrastar esta hipótesis con los fragmentos y términos de los casos."
        )
    # Para justificar B, confirmar con evidencia de un caso; un MRR bajo no demuestra
    # por sí solo que el problema sea de vocabulario.
    HIPOTESIS_JUSTIFICADA = bool(HIPOTESIS_EXTENSION and problemas_ranking)
    declaracion = {"opcion": "B", "hipotesis": HIPOTESIS_EXTENSION or
        "No se detectó un fallo de ranking; B solo sería una prueba exploratoria.",
        "ids_ranking": problemas_ranking, "rrf_c": 60, "candidatos_por_ruta": 20,
        "fecha_antes_de_medir": datetime.now(timezone.utc).isoformat(),
        "necesita_revision_causal": True}
    guardar_json(EVIDENCIAS / "hipotesis_extension.json", declaracion)
    print(declaracion["hipotesis"])
else:
    print("PENDIENTE: no se elige una extensión a partir de métricas que aún no existen.")
''')
code('''
from rank_bm25 import BM25Okapi

class RecuperadorHibrido:
    def __init__(self, base, fragmentos, candidatos=20, rrf_c=60):
        self.base = base
        self.fragmentos = fragmentos
        self.candidatos = candidatos
        self.rrf_c = rrf_c
        self.bm25 = BM25Okapi([self.tokenizar(c.text) for c in fragmentos])

    @staticmethod
    def tokenizar(texto):
        # Igual tratamiento en documentos y preguntas; preserva números y siglas.
        return re.findall(r"\\w+", rp._normalizar_texto(texto))

    def retrieve(self, question, top_k=5):
        dense = self.base.retrieve(question, top_k=max(top_k, self.candidatos))
        lexical_scores = self.bm25.get_scores(self.tokenizar(question))
        indices = sorted(range(len(self.fragmentos)),
                         key=lambda i: (-float(lexical_scores[i]), self.fragmentos[i].id))
        # No añadimos coincidencias de score cero: no aportan evidencia léxica.
        indices = [i for i in indices if lexical_scores[i] > 0][:max(top_k, self.candidatos)]
        lexical = [{"chunk_id": self.fragmentos[i].id, "document": self.fragmentos[i].document,
                    "text": self.fragmentos[i].text, "score": float(lexical_scores[i])}
                   for i in indices]
        scores, contenidos = {}, {}
        for lista in (dense, lexical):
            for rank, h in enumerate(lista, 1):
                cid = h["chunk_id"]
                scores[cid] = scores.get(cid, 0.0) + 1 / (self.rrf_c + rank)
                contenidos[cid] = h
        orden = sorted(scores, key=lambda cid: (-scores[cid], cid))[:top_k]
        return [{**contenidos[cid], "score": scores[cid]} for cid in orden]

    def build_prompt(self, question, contexts):
        return self.base.build_prompt(question, contexts)

    def generate(self, prompt):
        salida = self.base.generate(prompt)
        self.ultima_generacion = self.base.ultima_generacion
        return salida

reportes_hibridos = {}
comparacion = None
if reportes and (HIPOTESIS_JUSTIFICADA or EJECUTAR_COMPARACION_EXPLORATORIA):
    hibrido = PipelineConEvidencias(RecuperadorHibrido(pipeline, chunks))
    for k in (3, 5):
        # La Opción B exige comparar recuperación: no necesita otras 20 generaciones.
        reportes_hibridos[k] = evaluation.evaluate_retrieval(golden, hibrido, k=k, generar=False)
    filas_hibridas = [r for k in (3, 5) for r in reportes_hibridos[k]["rows"]]
    evaluation.escribir_csv(filas_hibridas, ROOT / "resultados_extension.csv", FILA_BASELINE["model"])
    guardar_json(EVIDENCIAS / "respuestas_extension.json", hibrido.exportar(golden, [3, 5]))
    _, tabla_hibrida = resumen_desde_csv(ROOT / "resultados_extension.csv")
    comparacion = tabla_baseline[["k", "Hit Rate", "MRR"]].merge(
        tabla_hibrida[["k", "Hit Rate", "MRR"]], on="k", suffixes=(" baseline", " híbrido"))
    comparacion["delta Hit Rate"] = comparacion["Hit Rate híbrido"] - comparacion["Hit Rate baseline"]
    comparacion["delta MRR"] = comparacion["MRR híbrido"] - comparacion["MRR baseline"]
    display(comparacion)
    comparacion.to_csv(EVIDENCIAS / "comparacion_extension.csv", index=False)
else:
    print("PENDIENTE: baseline medido y una hipótesis de extensión; no se atribuyen mejoras.")
''')
md(r'''
**Lectura del resultado:** la fusión mejora un poco MRR@5, pero reduce Hit Rate@3.
Por eso conservamos el denso como baseline. La extensión solo midió recuperación;
no se atribuyen cambios en la calidad de las respuestas.
''')
md(r'''
## Parte 4 — Reflexión

Redactamos las dos respuestas solicitadas a partir de las cifras medidas: el denominador
correcto de Hit Rate y una pregunta global que exige sintetizar todo el corpus.
''')
code('''
reflexion1 = None
if reportes:
    r = reportes[5]
    positivos, total = r["n_respondibles"], r["n_preguntas"]
    aciertos = sum(bool(f["hit"]) for f in r["rows"] if f["respondible"])
    def fmt(x): return "sin medir" if x is None or not np.isfinite(x) else f"{x:.3f}"
    reflexion1 = f"""En mi evaluación con k=5 hay {positivos} preguntas respondibles de {total};
    recuperé evidencia para {aciertos}. El Hit Rate correcto es {r['hit_rate']:.3f}, mientras que
    incluir las negativas en el denominador produciría {aciertos / total:.3f}. Ese cálculo mezcla
    recuperación y composición del verificador: castiga consultas para las que no existe
    ningún fragmento correcto. El techo histórico de 0.70 correspondía a siete respondibles
    entre diez; con mi distribución, el techo erróneo sería {positivos / total:.2f}. Al excluir
    las negativas, un recuperador perfecto puede alcanzar 1.00. Esto no evalúa su comportamiento
    cuando falta evidencia. Para eso reporto abstención correcta ({fmt(r['abstencion_correcta'])})
    y abstención indebida ({fmt(r['abstencion_indebida'])}). La primera comprueba si evita responder
    sin respaldo; la segunda muestra si también rechaza preguntas que sí podría contestar.
    Interpretarlas juntas impide premiar un sistema que se abstiene siempre."""
    reflexion1 = " ".join(reflexion1.split())
    display(Markdown(reflexion1))
    print("Palabras:", len(reflexion1.split()))
else:
    print("Reflexión 1 PENDIENTE: necesita tus resultados.csv y sus cifras reales.")

reflexion2 = """Mi pregunta global es: ¿qué decisiones de diseño explican las fallas silenciosas de
un RAG y cómo se conectan con su evaluación a lo largo de mis notas de embeddings,
fragmentación y recuperación? El RAG vectorial recupera fragmentos parecidos a una consulta y entrega
solo tres o cinco al generador. Esa selección puede omitir temas menos cercanos a la
formulación, aunque sean frecuentes o importantes en el conjunto. Aumentar k no garantiza
cobertura equilibrada y puede superar el contexto disponible. GraphRAG construye un grafo
de entidades y relaciones, identifica comunidades y prepara resúmenes que permiten combinar
evidencia distribuida para preguntas globales. Su búsqueda global sintetiza respuestas parciales
basadas en esos resúmenes. Esto aporta una organización del corpus que mi baseline no
construye, aunque también añade costo de indexación y posibles errores de extracción o resumen.
No demuestra automáticamente una mejora: requeriría preguntas globales y una evaluación específica."""
reflexion2 = " ".join(reflexion2.split())
display(Markdown(reflexion2))
print("Palabras:", len(reflexion2.split()))
assert 100 <= len(reflexion2.split()) <= 150
if reflexion1:
    assert 100 <= len(reflexion1.split()) <= 150
guardar_json(EVIDENCIAS / "reflexiones_borrador.json", {
    "pregunta1": reflexion1, "pregunta2": reflexion2,
    "fuente_graphrag": "https://arxiv.org/abs/2404.16130"})
''')
md(r'''
## Cierre y reproducibilidad

El checklist muestra qué se ejecutó y qué dato no se pudo verificar. Los CSV, respuestas,
fragmentos y versiones se guardan en `evidencias/`; el informe PDF reúne los resultados.
''')
code('''
abstenciones_completas = bool(reportes) and all(
    row["abstuvo"] is not None for report in reportes.values() for row in report["rows"])
checklist = [
    ("Parte 0: ingesta, truncamiento y dos consultas", all((EVIDENCIAS / f).exists() for f in
        ["parte0a_ingesta.txt", "parte0b_aviso.txt", "parte0b_truncamiento.json", "parte0c_vecinos.json"])),
    ("Corpus: 5 documentos aceptados y 50 páginas (originales o exportadas)", CORPUS_LISTO),
    ("Baseline bge-m3 en Qdrant contenedor", pipeline is not None),
    ("Golden set completo y validado", GOLDEN_LISTO),
    ("20 filas crudas baseline en esta ejecución", bool(reportes)),
    ("Abstención medida en las 20 consultas", abstenciones_completas),
    ("Tres casos con evidencia generada", len(casos_dificiles) == 3),
    ("Extensión medida con el mismo golden set", bool(reportes_hibridos)),
    ("Fila del generador con verified_at", bool(fila_generador.get("verified_at"))),
    ("Reflexión 1 con cifras reales", reflexion1 is not None),
]
display(pd.DataFrame(checklist, columns=["entregable", "verificado"] ))
guardar_json(EVIDENCIAS / "estado_entrega.json", dict(checklist))

# La instantánea permite reproducir las versiones instaladas sin mostrar variables de entorno.
import importlib.metadata
versiones = {d.metadata["Name"]: d.version for d in importlib.metadata.distributions()
             if d.metadata.get("Name")}
guardar_json(EVIDENCIAS / "versiones_entorno.json", versiones)
print("Evidencias guardadas en:", EVIDENCIAS)
print("Además: revisar manualmente ingesta, golden, diagnósticos e interpretación de la extensión.")
''')
md(r'''
## Fuentes

Enunciado: `../taller-02-rag-vector-search.pdf` (2026-09-23). Modelos: anexo del enunciado
y `h200-usfq-profesor.ipynb`. Documentos: `corpus_manifest.json`. GraphRAG: Edge et al. (2024).
''')

md(r'''
## Revisión final

La siguiente celda comprueba las huellas de los resultados, conserva las métricas y genera
el informe. Los diagnósticos completos están en `REVISION_FINAL.md`; la tabla oficial no
permite confirmar la identidad de `open_weight_pequeno` con los materiales disponibles.
''')
code('''
from pathlib import Path
import runpy
from IPython.display import display, Markdown
runpy.run_path(str(Path.cwd() / "scripts/cerrar_entrega.py"), run_name="__main__")
print("Revisión guardada en REVISION_FINAL.md; informe completo: Informe_Taller_02.pdf")
''')

nb=nbf.v4.new_notebook(cells=cells, metadata={
    'kernelspec': {'display_name':'Taller 02 RAG', 'language':'python', 'name':'taller02-rag'},
    'language_info': {'name':'python','version':'3.12.14'},
})
nbf.validate(nb)
path=Path(__file__).resolve().parents[1]/'Taller_02_RAG_VectorSearch.ipynb'
nbf.write(nb,path)
print(path, len(cells), 'celdas')
