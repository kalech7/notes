"""Verificaciones sin H200: validación, métricas, caché, RRF y golden real.
Los datos sintéticos de estas pruebas NO se escriben como resultados experimentales.
"""
from pathlib import Path
import ast
import json
import os
import tempfile
import nbformat
import numpy as np
import pandas as pd
import re
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
os.environ['EMBEDDING_BACKEND']='local'
os.environ['QDRANT_URL']=':memory:'
import rag_pipeline as rp
import evaluation
from ingestion import read_document, Chunk
from rank_bm25 import BM25Okapi
nb=nbformat.read(ROOT/'Taller_02_RAG_VectorSearch.ipynb',as_version=4)
nbformat.validate(nb)
namespace=dict(np=np,pd=pd,re=re,rp=rp,BM25Okapi=BM25Okapi)
funciones={'validar_golden','resumen_desde_csv','cobertura_evidencias',
           'PipelineConEvidencias','RecuperadorHibrido'}
for n,cell in enumerate(nb.cells):
    if cell.cell_type!='code': continue
    tree=ast.parse(cell.source,filename=f'celda_{n}')
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name in funciones:
            exec(compile(ast.Module(body=[node],type_ignores=[]),f'celda_{n}','exec'),namespace)
print('OK: estructura notebook y sintaxis de todas las celdas')

golden=json.loads((ROOT/'golden_set.json').read_text())
docs={p.name:read_document(p) for p in (ROOT/'corpus').glob('*.md') if p.name!='README.md'}
errors=namespace['validar_golden'](golden,docs)
assert not errors,errors
assert len(golden)==10 and sum(bool(i['documentos_fuente']) for i in golden)==8
assert len(docs)==22
print('OK: diez preguntas, ocho respondibles, dos negativas y frases verificadas en 22 notas')

class Fake:
    def __init__(self): self.calls=0; self.retrieve_calls=0
    def retrieve(self,question,top_k=5):
        self.retrieve_calls+=1
        return [{'document':'a.md','chunk_id':'a0','text':'evidencia','score':.9}]
    def build_prompt(self,question,contexts): return question
    def generate(self,prompt):
        self.calls+=1;self.ultima_generacion='ollama:prueba'
        return rp.ABSTENCION if prompt=='negativa' else 'Respuesta respaldada.'
fake=Fake();wrapped=namespace['PipelineConEvidencias'](fake)
items=[dict(id=1,tipo='simple',pregunta='positiva',documentos_fuente=['a.md'],fragmento_esperado='evidencia'),
       dict(id=2,tipo='negativo',pregunta='negativa',documentos_fuente=[],fragmento_esperado='')]
r=evaluation.evaluate_retrieval(items,wrapped,k=3,generar=True)
assert r['hit_rate']==1 and r['mrr']==1
assert r['abstencion_correcta']==1 and r['abstencion_indebida']==0
assert r['rows'][1]['hit'] is None and r['rows'][1]['reciprocal_rank'] is None
wrapped.answer('positiva',3)
assert fake.calls==2 and fake.retrieve_calls==2
print('OK: negativas excluidas del denominador; tasas separadas; una llamada por pregunta/k')

with tempfile.TemporaryDirectory() as temp:
    path=Path(temp)/'test.csv'
    evaluation.escribir_csv(r['rows'],path,'modelo-de-prueba')
    df,tabla=namespace['resumen_desde_csv'](path)
    assert tabla.iloc[0]['Hit Rate']==1 and tabla.iloc[0]['abstención correcta']==1
    r2=evaluation.evaluate_retrieval(items,Fake(),k=5,generar=False)
    evaluation.escribir_csv(r2['rows'],path,'modelo-de-prueba')
    df,tabla=namespace['resumen_desde_csv'](path)
    assert pd.isna(tabla.iloc[0]['abstención correcta'])
print('OK: CSV reconstruye métricas y conserva abstención no medida')

class Inspection(Fake):
    def generate(self,prompt):
        self.ultima_generacion='modo inspección (prueba)'
        return rp.ABSTENCION
out=namespace['PipelineConEvidencias'](Inspection()).answer('positiva')
assert out['abstained'] is None
print('OK: la frase dentro de un prompt de inspección no cuenta como abstención')

fragments=[Chunk('a','texto general','a.md',0,{}),
           Chunk('b','claveunica','b.md',0,{}),
           Chunk('c','otra cosa','c.md',0,{})]
class Dense:
    def retrieve(self,question,top_k=5):
        c=fragments[0]
        return [dict(chunk_id=c.id,document=c.document,text=c.text,score=.8)]
hybrid=namespace['RecuperadorHibrido'](Dense(),fragments)
hits=hybrid.retrieve('claveunica',top_k=3)
assert {h['chunk_id'] for h in hits}=={'a','b'}
assert all(np.isclose(h['score'],1/61) for h in hits)
assert len({h['chunk_id'] for h in hits})==len(hits)
print('OK: RRF usa unión, recupera candidato léxico ausente en denso y no duplica IDs')

manifest=json.loads((ROOT/'corpus_manifest.json').read_text())
from pypdf import PdfReader
import hashlib
assert sum(len(PdfReader(ROOT/d['pdf_exportado']).pages) for d in manifest['documentos'])==70
assert all(hashlib.sha256((ROOT/'corpus'/d['documento']).read_bytes()).hexdigest()==d['sha256']
           for d in manifest['documentos'])
print('OK: 70 páginas de exportación verificadas y copias idénticas a los hashes del manifiesto')
