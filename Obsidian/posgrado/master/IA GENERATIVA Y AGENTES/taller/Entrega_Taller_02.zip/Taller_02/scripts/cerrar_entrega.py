"""Audita resultados guardados y genera el informe; no repite ni altera el experimento.

La revisión editorial está ligada a hashes: si cambian los resultados, debe revisarse
antes de atribuirle conclusiones anteriores. No inventa la fila del generador del curso.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import sys

import nbformat
import pandas as pd
from nbconvert import HTMLExporter

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from rag_pipeline import _normalizar_texto


def leer(nombre):
    return json.loads((ROOT / nombre).read_text(encoding='utf-8'))


def guardar(nombre, valor):
    (ROOT / nombre).write_text(json.dumps(valor, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def tabla(headers, rows):
    def esc(x):
        return str(x).replace('|', '\\|').replace('\n', ' ')
    return '\n'.join(['| ' + ' | '.join(map(esc, headers)) + ' |',
                      '| ' + ' | '.join(['---'] * len(headers)) + ' |'] +
                     ['| ' + ' | '.join(map(esc, row)) + ' |' for row in rows])


def bloque(texto):
    return '\n```text\n' + texto.strip() + '\n```\n'


def main():
    revision = leer('revision_diagnosticos.json')
    for nombre, esperado in revision['huellas_fuentes'].items():
        actual = hashlib.sha256((ROOT / nombre).read_bytes()).hexdigest()
        if actual != esperado:
            raise RuntimeError(f'Cambiaron los datos de {nombre}; revisar diagnósticos antes de publicar.')
    casos = leer('evidencias/tres_casos_dificiles.json')
    golden = {x['id']: x for x in leer('golden_set.json')}
    chunks = [json.loads(s) for s in (ROOT / 'data/chunks_baseline.jsonl').read_text().splitlines()]
    respuestas = leer('evidencias/respuestas_baseline.json')
    base = pd.read_csv(ROOT / 'resultados.csv')
    ext = pd.read_csv(ROOT / 'resultados_extension.csv')
    assert len(base) == len(ext) == len(respuestas) == 20
    assert all(x['salida']['generator'] == 'ollama:gemma3:4b' for x in respuestas)
    resumen = leer('evidencias/resumen_baseline.json')
    config = leer('evidencias/configuracion.json')
    contraste = leer('evidencias/contraste_generador.json')
    reflexiones = leer('evidencias/reflexiones_borrador.json')
    for texto in (reflexiones['pregunta1'], reflexiones['pregunta2']):
        assert 100 <= len(texto.split()) <= 150
    secciones = []
    for c in casos:
        rev = revision['casos'][str(c['id'])]
        c['diagnostico_revisado'] = rev['diagnostico']
        c['revision'] = rev | {'revisado_por': revision['revision_por']}
        anclas = []
        for e in golden[c['id']]['evidencias_esperadas']:
            frase = _normalizar_texto(e['frase'])
            indexados = [x['id'] for x in chunks if x['document'] == e['documento']
                         and frase in _normalizar_texto(x['text'])]
            recuperados = [i + 1 for i, h in enumerate(c['hits']) if h['document'] == e['documento']
                           and frase in _normalizar_texto(h['text'])]
            assert indexados, 'La evidencia revisada ya no está en el índice'
            anclas.append({'frase': e['frase'], 'indexados': indexados, 'puestos_recuperados': recuperados})
        c['revision']['anclas_verificadas'] = anclas
        coverage = sum(bool(a['puestos_recuperados']) for a in anclas) / len(anclas)
        c['revision']['cobertura_literal'] = coverage
        s = f"### Caso {c['id']}: {rev['etapa_principal']}\n\n"
        s += f"**Pregunta:** {c['pregunta']}\n\n**Respuesta real:** {c['respuesta_completa']}\n\n"
        s += rev['diagnostico'] + '\n\n' + rev['evidencia_causal'] + '\n\n'
        s += '**Evidencia de ingesta:**\n\n' + tabla(['Fuente', 'Caracteres útiles', 'Rechazada', 'Error'],
            [[x['documento'], x['caracteres_utiles'], x['rechazado'], x['error']] for x in c['ingesta_fuentes']])
        s += '\n\n**Vecinos entregados al generador:**\n\n' + tabla(['Puesto', 'Fragmento', 'Coseno'],
            [[i+1, h['chunk_id'], f"{h['score']:.8f}"] for i,h in enumerate(c['hits'])])
        s += '\n\n**Anclas del golden:**\n\n' + tabla(['Frase', 'En el índice', 'Puesto en top-5'],
            [[a['frase'], ', '.join(a['indexados']), a['puestos_recuperados'] or 'Ausente'] for a in anclas])
        s += f"\n\n**Acción propuesta:** {rev['accion']}\n\n**Alcance de la conclusión:** {rev['limite']}\n"
        secciones.append(s)
    guardar('evidencias/tres_casos_dificiles.json', casos)
    pares = base.merge(ext, on=['id', 'k'], suffixes=('_base', '_hibrido'))
    cambios = pares[pares.respondible_base &
                    (pares.reciprocal_rank_base != pares.reciprocal_rank_hibrido)]
    detalle = tabla(['Pregunta', 'k', 'Puesto denso', 'Puesto híbrido', 'Δ RR'],
        [[int(r.id), int(r.k), int(r.posicion_base) if pd.notna(r.posicion_base) else 'Sin acierto',
          int(r.posicion_hibrido) if pd.notna(r.posicion_hibrido) else 'Sin acierto',
          f'{r.reciprocal_rank_hibrido-r.reciprocal_rank_base:+.6f}'] for _,r in cambios.iterrows()])
    interpretacion = '''La hipótesis se registró antes de medir la extensión en `evidencias/hipotesis_extension.json`.
Los casos 5 y 6 permiten justificar una prueba de recuperación: hay evidencia indexada que el top-5 omite.
Eso no demuestra que la causa sea únicamente vocabulario ni que BM25 vaya a corregirla. El caso 4 apunta
además a generación y no queda resuelto por una mejora de ranking.

Con k=3, la fusión pierde el acierto de la pregunta 10: su primer fragmento relevante pasa del puesto 1
al 4. Hit Rate baja de 7/8 a 6/8, mientras MRR se mantiene en 0,5625 porque las preguntas 2, 3, 4 y 5
adelantan sus primeros aciertos. Con k=5, ambos métodos aciertan 7/8; esos adelantos compensan
parcialmente la caída de la pregunta 10 y MRR pasa de 0,5625 a 0,59375 (Δ=0,03125).
La pregunta 6 sigue sin acierto y la 5 sigue sin el pasaje esperado sobre duplicación por solapamiento.

**Decisión:** conservar el recuperador denso como baseline. No hay una mejora uniforme que justifique
sustituirlo: la extensión queda como comparación medida, con un pequeño beneficio de orden en k=5
y una pérdida en k=3. No se generaron respuestas de la extensión; por tanto, no se le atribuyen
mejoras de abstención ni de calidad final. Ocho preguntas respondibles no permiten generalizar.
'''
    cierre = '# Revisión final del experimento\n\n'
    cierre += 'Revisión realizada sobre las salidas guardadas el 27 de septiembre de 2026. Las métricas y las respuestas originales se conservan.\n\n'
    cierre += '## Contraste de modelos\n\n'
    cierre += ('El anexo del enunciado (p. 9) confirma `embed_local_multilingue`: `BAAI/bge-m3`, '
               '1024 dimensiones, 8192 tokens y `verified_at=2026-08-27`. Se ejecutó en CUDA local; '
               'el notebook del profesor, celda 21, recomienda `sentence-transformers` local como plan B y declararlo.\n\n')
    cierre += (f"El generador medido es **{contraste['modelo_ejecutado']}**, {contraste['details']['quantization_level']}, "
               f"verificado localmente el {contraste['fecha_verificacion_local'][:10]}. "
               f"Huella Ollama: `{contraste['digest']}`. Contexto configurado: 8192; temperatura: 0; máximo de salida: 512.\n\n")
    cierre += (contraste['estado_contraste'] + ' El notebook del profesor declara GLM-5.3-Flash en la H200 con fecha 2026-09-22, '
               'pero no contiene la tabla semestral ni relaciona ese servicio con la fila local. '
               '**La fecha de verificación local no se presenta como `verified_at` del curso.**\n\n')
    cierre += '## Diagnósticos revisados\n\n' + '\n\n'.join(secciones)
    cierre += '\n\n## Interpretación de la extensión\n\n' + interpretacion + '\n\n' + detalle
    cierre += '''\n\n## Otras limitaciones observadas

En k=3, la respuesta 1 primero afirma que el ranking se conserva y después que puede cambiar:
es una contradicción que Hit Rate y MRR no detectan. En k=5 la explicación sí distingue orden y escala.
La adversarial 9 se abstiene en k=3 y responde 0,6 en k=5, sin repetir la instrucción maliciosa;
un solo caso no demuestra robustez general. Las tasas de abstención no son métricas de fidelidad.

La revisión causal quedó realizada por Codex sobre los registros. No equivale a una revisión docente
ni a una validación experimental de cada intervención propuesta. El único dato externo que falta
para comprobar la identidad de la fila local oficial es `modelos-2026-1.json` o una fuente del curso
que publique su modelo y `verified_at`. Se mantiene como no verificable, sin inventarlo.
'''
    (ROOT / 'REVISION_FINAL.md').write_text(cierre, encoding='utf-8')
    metricas = pd.read_csv(ROOT / 'evidencias/tabla_metricas_baseline.csv')
    comparacion = pd.read_csv(ROOT / 'evidencias/comparacion_extension.csv')
    informe = '''# Informe — Taller 02: RAG sobre notas de embeddings, recuperación y evaluación

MMIA 6013 · Universidad San Francisco de Quito · Ejecución y revisión: 27 de septiembre de 2026

## Resultado y alcance

Se construyó y ejecutó un RAG local sobre 22 notas en español: 109 fragmentos de texto, embeddings
BGE-M3 en GPU NVIDIA RTX 3050 Ti, Qdrant persistente en contenedor y generación con Gemma 3 4B mediante
Ollama. Se evaluaron diez preguntas con k=3 y k=5 y se comparó recuperación densa con BM25+RRF.
El baseline obtiene Hit Rate 0,875 y MRR 0,5625 en ambos cortes. La abstención correcta es 1,0;
la indebida baja de 0,5 a 0,25 al aumentar k. Son resultados del experimento, no una certificación
de que todas las respuestas sean correctas.

## Corpus, arquitectura y fragmentación

El corpus contiene las notas 28–49 del usuario, 26 186 palabras. Las exportaciones A4 suman 70 páginas;
son páginas de transcripción y no páginas originales. Se indexan los Markdown originales. Se conservaron
sus hashes en `corpus_manifest.json`; no se rechazó ninguna de las 22 notas por falta de texto.
Se pierden imágenes y diagramas como información visual, y tablas, fórmulas y enlaces conservan
sintaxis textual que puede dificultar su interpretación. No se realizó OCR.

```text
Markdown → auditoría → fragmentos → BGE-M3 CUDA → Qdrant persistente
Pregunta → mismo BGE-M3 → top-k → prompt con contexto → Gemma 3 → respuesta/abstención
```

Los bloques son de 512 tokens, con 102 de solapamiento: avance de 410. Se eligió un tamaño cercano a
las unidades explicativas de las notas para limitar la mezcla de temas; el solapamiento ofrece una
segunda oportunidad a información cerca del corte. El mayor fragmento observado tras decodificar y
volver a tokenizar mide 515 tokens con especiales, por debajo del límite de 8192. Esto descarta
truncamiento por ese límite en los fragmentos medidos; no demuestra que cada vector preserve cada detalle.
Los bloques no se fijaron en 8192 simplemente por caber. La indexación y las consultas usan el mismo
modelo y vectores normalizados. CUDA opera con pesos float16 y lotes de 4; la salida se normaliza en float32.

Qdrant v1.15.1 corre en el contenedor Podman `lab02-qdrant`, con almacenamiento en `qdrant_storage/`.
Podman sustituyó a Docker Desktop después de un fallo de su máquina virtual, conservando la API local
y la persistencia exigidas. No se usó Qdrant en memoria para el baseline.

## Parte 0: fallas reproducidas

### 0.a — PDF escaneado

`load_corpus` cuenta caracteres útiles y rechaza documentos bajo el umbral de 200: el PDF escaneado
aporta cero caracteres. Sin ese filtro podría producir marcadores sin contenido; el filtro adicional
de 20 caracteres útiles por fragmento aún evita indexarlos en el código entregado.

'''
    informe += bloque((ROOT / 'evidencias/parte0a_ingesta.txt').read_text())
    informe += '\n### 0.b — Truncamiento\n\n'
    informe += bloque((ROOT / 'evidencias/parte0b_aviso.txt').read_text())
    informe += bloque(json.dumps(leer('evidencias/parte0b_truncamiento.json'), ensure_ascii=False, indent=2))
    informe += '\nEl coseno cercano a 1 muestra que ambos textos llegan al modelo con el mismo prefijo. No prueba equivalencia de sus contenidos completos.\n\n'
    informe += '### 0.c — Vecinos sin respuesta\n\n'
    informe += bloque(json.dumps(leer('evidencias/parte0c_vecinos.json'), ensure_ascii=False, indent=2))
    informe += '\nLa cercanía de vecinos no indica que exista respuesta. Hit Rate, aplicado solo a respondibles, no mide estas negativas: se evalúa su abstención.\n\n'
    informe += '## Golden set y métricas\n\n'
    informe += ('El golden contiene cuatro simples, tres multi-fragmento, dos negativas y una adversarial respondible: '
                'ocho respondibles y dos negativas. Se anotó por documento y frase verificable. '
                'La adversarial tiene evidencia y debe responder al contenido legítimo ignorando la instrucción maliciosa. '
                'Las veinte filas proceden de diez preguntas por dos valores de k. Se realizaron veinte generaciones '
                'locales; las tres demostraciones reutilizan la misma caché. No hubo gasto de API.\n\n')
    informe += tabla(['k','Respondibles','Negativas','Hit Rate','MRR','Abstención correcta','Abstención indebida'],
        [[int(r['k']),int(r['respondibles']),int(r['negativas']),r['Hit Rate'],r['MRR'],r['abstención correcta'],r['abstención indebida']] for _,r in metricas.iterrows()])
    informe += ('\n\nHit Rate cuenta al menos un acierto; MRR promedia los recíprocos del primer acierto. '
                'Las negativas se excluyen de ambos denominadores. La cobertura por anclas es complementaria y literal; '
                'puede omitir evidencia semánticamente equivalente, como muestra el caso 4.\n\n')
    informe += '## Tres consultas de prueba con sus top-5\n\n'
    for prueba in leer('evidencias/parte1_top5.json'):
        informe += f"### Consulta {prueba['id']}\n\n{prueba['pregunta']}\n\n"
        informe += tabla(['Puesto','Fragmento/documento','Coseno'],
                         [[i+1,h['chunk_id'],f"{h['score']:.8f}"] for i,h in enumerate(prueba['hits'])])
        informe += '\n\n**Respuesta real:**\n' + bloque(prueba['salida']['answer'])
    informe += '\n' + cierre.replace('# Revisión final del experimento','## Revisión final del experimento',1)
    informe += '\n\n## Resultados de la extensión\n\n'
    informe += tabla(list(comparacion.columns),comparacion.values.tolist())
    informe += '\n\n## Parte 4: reflexiones\n\n### 1. Denominador y abstención\n\n' + reflexiones['pregunta1']
    informe += '\n\n### 2. Pregunta global y GraphRAG\n\n' + reflexiones['pregunta2']
    informe += '''\n\n## Reproducción y fuentes

```bash
# Entorno GPU preparado; no ejecutar dos contenedores en el mismo puerto.
podman start lab02-qdrant
.venv/bin/python scripts/verificar_notebook.py
.venv/bin/jupyter nbconvert --to notebook --execute --inplace Taller_02_RAG_VectorSearch.ipynb
.venv/bin/jupyter nbconvert --to html Taller_02_RAG_VectorSearch.ipynb
```

`requirements-lock.txt` fija las versiones verificadas y el índice de PyTorch CUDA.
`.env.example` declara la configuración; `.env` permanece excluido del repositorio.
`resultados.csv` y `resultados_extension.csv` conservan las filas crudas. Las respuestas completas,
vecinos y auditorías están en `evidencias/`. La revisión de este informe está ligada a hashes en
`revision_diagnosticos.json`: si cambian las salidas, el cierre pide revisarlas antes de reutilizar conclusiones.

Fuentes documentales: enunciado `taller-02-rag-vector-search.pdf` de 2026-09-23, pp. 2, 4 y 9;
notebook `h200-usfq-profesor.ipynb`, celdas 1 y 21 (catálogo declarado verificado el 2026-09-22);
notas originales y hashes en `corpus_manifest.json`. GraphRAG: Edge et al. (2024),
[From Local to Global](https://arxiv.org/abs/2404.16130). El informe distingue fechas declaradas
por el curso de verificaciones locales; no reemplaza la fila oficial ausente por una suposición.

## Anexo: fragmentos completos de los tres casos diagnosticados

Los textos siguientes son los payloads recuperados, sin reescribir su contenido.
'''
    for c in casos:
        informe += f"\n### Caso {c['id']}\n"
        for i,h in enumerate(c['hits']):
            informe += f"\n#### Puesto {i+1} — {h['chunk_id']} — coseno {h['score']:.8f}\n"
            informe += bloque(h['text'])
    (ROOT / 'INFORME_ENTREGA.md').write_text(informe, encoding='utf-8')
    nb = nbformat.v4.new_notebook(cells=[nbformat.v4.new_markdown_cell(informe)])
    html, _ = HTMLExporter().from_notebook_node(nb)
    style = '''<style>
    @page { size: A4; margin: 16mm; }
    .jp-Notebook { max-width: 1050px; margin: auto; }
    pre, code { white-space: pre-wrap !important; overflow-wrap: anywhere; }
    table { width: 100%; table-layout: auto; font-size: 10px; }
    td, th { overflow-wrap: anywhere; }
    @media print {
      body { font-size: 10pt; } .jp-Notebook { padding: 0 !important; }
      .jp-Cell { padding: 0 !important; } .jp-InputPrompt { display: none; }
      h1,h2,h3,h4 { break-after: avoid; } tr { break-inside: avoid; }
      pre { font-size: 8pt; } a { color: #164e63; text-decoration: none; }
    }</style>'''
    html = html.replace('</head>', style + '</head>')
    (ROOT / 'Informe_Taller_02.html').write_text(html, encoding='utf-8')
    estado = leer('evidencias/estado_entrega.json')
    estado['Tres diagnósticos revisados contra ingesta, índice, contexto y respuesta'] = True
    estado['Extensión interpretada con cambios por pregunta y límites'] = True
    estado['Contraste documental del generador realizado y limitación declarada'] = True
    guardar('evidencias/estado_entrega.json', estado)
    guardar('evidencias/cierre_entrega.json', {
        'fecha_utc': datetime.now(timezone.utc).isoformat(),
        'diagnosticos_revisados': [c['id'] for c in casos],
        'metricas_originales_preservadas': True,
        'contraste_generador_realizado': True,
        'equivalencia_fila_oficial': contraste['coincidencia_con_fila_oficial'],
        'limitacion_externa': 'La tabla oficial del generador no está en los materiales disponibles.',
        'fuentes_revision_sha256': revision['huellas_fuentes'],
    })
    print('Diagnósticos, contraste y comparación revisados; informe HTML y Markdown generados.')
    return cierre


if __name__ == '__main__':
    main()
