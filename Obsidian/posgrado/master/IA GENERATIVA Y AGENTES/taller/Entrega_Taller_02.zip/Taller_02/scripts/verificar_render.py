from pathlib import Path
import json
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/google-chrome',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1000},device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.goto((root/'Taller_02_RAG_VectorSearch.html').as_uri(),wait_until='networkidle')
    page.wait_for_timeout(3000)
    result=page.evaluate('''() => ({
      title:document.title,
      headings:[...document.querySelectorAll('h1,h2,h3')].map(x=>x.innerText),
      tables:document.querySelectorAll('table').length,
      math:document.querySelectorAll('.MathJax, .MathJax_CHTML, mjx-container').length,
      mathErrors:[...document.querySelectorAll('.MathJax_Error,.mjx-merror')].map(x=>x.innerText),
      errors:document.querySelectorAll('.output_error,.jp-OutputArea-error').length,
      width:document.documentElement.scrollWidth, viewport:innerWidth,
      images:[...document.images].filter(x=>!x.complete || x.naturalWidth===0).map(x=>x.src),
      outputs:document.querySelectorAll('.jp-OutputArea-output').length
    })''')
    result['page_errors']=errors
    dest=root/'evidencias'/'render'
    dest.mkdir(exist_ok=True)
    page.screenshot(path=str(dest/'inicio.png'))
    for key,phrase in [('metricas','Parte 2.b'),('extension','Parte 3'),('cierre','Cierre —')]:
        heading=page.get_by_role('heading').filter(has_text=phrase).first
        if heading.count():
            heading.scroll_into_view_if_needed()
            page.screenshot(path=str(dest/(key+'.png')))
    (dest/'verificacion.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    browser.close()
