# Lab 02 — RAG con Vector Search y Evaluación

## Notebook implementado paso a paso

Abre [Taller_02_RAG_VectorSearch.ipynb](Taller_02_RAG_VectorSearch.ipynb) con el kernel
**Taller 02 RAG** o el intérprete `.venv/bin/python`. Contiene las Partes 0–4 del PDF,
explicadas en español, y guarda las salidas reales en `evidencias/`.

Se seleccionaron 22 notas de embeddings, RAG y evaluación de tu carpeta `notes`, con
26 186 palabras en español. `corpus_manifest.json` registra sus rutas y hashes. Las
exportaciones textuales A4 suman 70 páginas; los Markdown originales no tienen paginación.
El índice usa los Markdown directamente. `golden_set.json` contiene diez preguntas
anotadas sobre ese corpus, incluidas dos negativas y una adversarial respondible.

Los embeddings se ejecutan localmente en tu GPU NVIDIA: BGE-M3 en CUDA, float16 y
lotes de cuatro fragmentos. El baseline necesita el contenedor Qdrant. Inicia Docker y ejecuta `docker compose up -d`; luego vuelve a
ejecutar el notebook en orden. La generación usa Ollama y `gemma3:4b` como selección
local configurable; contrasta su nombre con la fila `open_weight_pequeno` del curso.
Los estados pendientes no se convierten en métricas ni se genera un CSV ficticio.

Verificación del 27 de septiembre de 2026: **23/23 celdas ejecutadas sin errores** (22 del experimento y una de cierre documental),
20 respuestas reales de `gemma3:4b`, 20 filas de baseline y 20 de búsqueda híbrida.
El notebook ahora resume cada paso y dirige el análisis extenso al informe PDF.
El HTML se revisó en Chrome: 14 tablas y 44 bloques de salida, sin errores de
JavaScript ni desbordamiento horizontal. La advertencia del tokenizador al contar 1200
tokens se eliminó solo de esa llamada de conteo: el texto largo nunca se pasa sin
truncar al modelo. La advertencia de IProgress se resolvió con `ipywidgets`.
El **aviso pedagógico del ingestor** al pedir bloques de 900 para MiniLM se conserva.
La evidencia está en `evidencias/verificacion_ejecucion.json` y
`evidencias/render/verificacion.json`, junto con capturas de la exportación.
Los tres diagnósticos y la interpretación de la extensión están revisados en `REVISION_FINAL.md`.
Se contrastó el generador con el enunciado y `h200-usfq-profesor.ipynb`: estos materiales
no identifican el modelo de la fila `open_weight_pequeno`. La correspondencia oficial
se declara no verificable; la versión local de `gemma3:4b` sí está documentada con su digest.
El notebook del profesor respalda `sentence-transformers` local como plan B.

Informe completo: [PDF](Informe_Taller_02.pdf), [HTML](Informe_Taller_02.html) y
[Markdown](INFORME_ENTREGA.md). El PDF incluye las evidencias y los pasajes completos
de los tres casos diagnosticados. Los análisis se ligan a los hashes de las salidas:
una nueva ejecución con resultados distintos exige revisar las conclusiones.

```bash
.venv/bin/python scripts/verificar_ejecucion.py
.venv/bin/python scripts/cerrar_entrega.py
uv run --with playwright==1.63.0 --python .venv/bin/python python scripts/exportar_informe.py
uv run --with playwright==1.63.0 --python .venv/bin/python python scripts/verificar_render.py
```

La celda de cierre se ejecutó después del experimento, leyendo sus resultados archivados,
sin repetir llamadas ni modificar los CSV. Los hashes permiten verificar esa separación.

Entorno del notebook: `requirements-notebook.txt`; versiones exactas instaladas:
`requirements-lock.txt`. El código del escritor CSV y las métricas del curso se reutilizan.
La extensión implementada es BM25 + búsqueda densa con RRF; su ejecución queda
condicionada al diagnóstico del baseline y a la hipótesis registrada antes de medir.

```bash
.venv/bin/python scripts/verificar_notebook.py
.venv/bin/jupyter nbconvert --to notebook --execute --inplace Taller_02_RAG_VectorSearch.ipynb
.venv/bin/jupyter nbconvert --to html Taller_02_RAG_VectorSearch.ipynb
```

`scripts/preparar_notas.py` reconstruye las copias y sus exportaciones;
`scripts/crear_notebook.py` regenera la estructura del notebook y **borra sus salidas**.

Andamiaje del Taller 2. Trae la ingesta, la fragmentación, el índice, la recuperación, el
prompt, **la llamada al LLM** y el evaluador; lo que el estudiante pone es el corpus, el
golden set, los parámetros con su justificación y el análisis.

> **Los embeddings son de `BAAI/bge-m3`, ejecutado en tu GPU NVIDIA.** No requieren
> VPN ni una API. La Parte 0 mantiene MiniLM para demostrar el truncamiento.
> Cuatro cosas que no fallarían por sí solas y aquí fallan o se miden: el PDF escaneado que
> se indexaría vacío, el fragmento que se truncaría en silencio, las preguntas negativas que
> pondrían un techo al Hit Rate, y la abstención que ningún detector por igualdad de cadena
> podría ver. El detalle está en la cabecera de cada archivo.

## Setup

```bash
pip install torch==2.7.1 --index-url https://download.pytorch.org/whl/cu128
pip install -r requirements.txt
cp .env.example .env            # embeddings locales en CUDA; sin claves
docker run -p 6333:6333 qdrant/qdrant       # o QDRANT_URL=":memory:" para correr sin Docker
```

`QDRANT_URL=":memory:"` es la misma API sin contenedor: sirve para la Parte 0 y para
depurar. El sábado se evalúa contra el contenedor, que es lo que persiste el índice.

## Qdrant en este equipo

La ejecución completa usa el contenedor `lab02-qdrant` de Podman porque Docker Desktop
falló al arrancar su máquina virtual. Los datos persisten en `qdrant_storage/` y la API
escucha en `http://localhost:6333`, igual que la configuración de Docker Compose.

```bash
podman start lab02-qdrant        # si está detenido
podman ps --filter name=lab02-qdrant
```

Para crearlo de nuevo si no existe (sin arrancar ambos contenedores a la vez):

```bash
mkdir -p qdrant_storage
podman run -d --name lab02-qdrant -p 127.0.0.1:6333:6333 \
  -v "$PWD/qdrant_storage:/qdrant/storage:Z" docker.io/qdrant/qdrant:v1.15.1
```

## Estructura

```
Lab-02-RAG-VectorSearch/
├── README.md
├── requirements.txt
├── .env.example
├── ingestion.py               Carga, parseo y fragmentación EN TOKENS del modelo
├── rag_pipeline.py            Ingesta → índice → recuperación → prompt → generación
├── evaluation.py              Hit Rate y MRR sobre respondibles; dos tasas de abstención; CSV crudo
├── golden_set_plantilla.json  Plantilla (10 preguntas, anotadas por documento y fragmento)
├── ejemplos/                  Corpus mínimo + un PDF escaneado, para la Parte 0 del taller
└── corpus/                    Tu corpus (lo creas tú)
```

## Baseline

1. Copia tus PDFs o `.txt`/`.md` en `corpus/`.
2. Completa `golden_set_plantilla.json` y guárdalo como `golden_set.json`.
3. `python rag_pipeline.py "una pregunta de prueba"`: ingesta, indexa, recupera y genera.
4. `python evaluation.py --k 5`: métricas y `resultados.csv`, una fila por consulta.

RAGAS, búsqueda híbrida y reranking son extensiones. Primero debe funcionar el baseline.

## Las tres fallas que no fallan (Parte 0 del taller)

La Parte 0 corre con el MiniLM de los notebooks **en tu máquina** (`EMBEDDING_BACKEND=local`):
sin clave, sin VPN, sin Docker y en un minuto. Es la **única** parte del taller que no usa
`bge-m3`, y es a propósito: la 0.b necesita un modelo que trunque a 128 tokens.

```bash
EMBEDDING_BACKEND=local EMBEDDING_MODEL=sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2 QDRANT_URL=":memory:" python rag_pipeline.py "¿cuántos días de vacaciones puedo transferir?"
```

- **El PDF escaneado.** `ejemplos/instructivo_escaneado.pdf` no tiene capa de texto. Sin
  comprobación se indexaría como un fragmento hecho de `[page=1] [page=2]`, sin ninguna
  excepción. La ingesta avisa: `0 caracteres útiles en 2 página(s) … NO se indexa`. Si tu
  corpus real trae uno, ese documento no está aunque el índice diga que sí.
- **El fragmento que se corta.** El MiniLM trunca a **128 tokens** de secuencia
  (`fuentes/modelos/modelos-2026-1.json`, fila `embed_notebook_s2`, verificado 2026-08-27),
  y lo hace sin avisar. La ingesta fragmenta en tokens del **mismo** tokenizador y lee el
  tope del modelo; si pides un fragmento mayor, avisa cuánto se pierde. Pide
  `chunk_tokens=900` y míralo.
- **El índice que no se queja.** Pregunta algo que no está (`"¿cuál es la política de
  mascotas?"`): devuelve cinco vecinos con puntajes de aspecto sano. Ningún Hit Rate
  detecta esto; por eso el golden set lleva negativas y el evaluador mide si el sistema
  **se abstiene**.

## El modelo de embeddings: `bge-m3` en tu GPU

La configuración preparada en `.env` y `.env.example` es:

```dotenv
EMBEDDING_BACKEND=local
EMBEDDING_MODEL=BAAI/bge-m3
EMBEDDING_DEVICE=cuda
EMBEDDING_DTYPE=float16
EMBEDDING_BATCH_SIZE=4
```

La primera ejecución descarga el modelo de Hugging Face. Después la inferencia ocurre
localmente. Se requiere PyTorch con CUDA; si CUDA no está disponible, la configuración
explícita falla en lugar de pasar silenciosamente a CPU. Reinicia el kernel si estaba
abierto durante la instalación. `auto` y `cpu` también son opciones de `EMBEDDING_DEVICE`.
Los vectores se normalizan en float32; la precisión float16 corresponde a los pesos.
El notebook libera MiniLM antes de cargar BGE-M3 para reducir el uso de memoria.

Para verificar GPU, indexación y consultas sin Docker ni generar respuestas:

```bash
.venv/bin/python scripts/verificar_gpu.py
```

### Ruta alternativa: H200 del curso

Con `EMBEDDING_BACKEND=h200`, `rag_pipeline.py` calcula los embeddings con **`bge-m3`** (fila `embed_local_multilingue` de
la tabla semestral): multilingüe —el corpus por defecto del taller está en español—, 1024
dimensiones y un tope de **8192 tokens**. Lo sirve el Ollama de la H200 de la USFQ
(`H200_EMBED_URL`, por defecto `http://172.28.230.10:11434`); el cliente busca en su catálogo
el id servido que empieza por `bge-m3`, en vez de escribirlo, y le pide `truncate: false`:
si un texto no cabe, el servidor da error en vez de recortarlo en silencio. El tokenizador
con el que se fragmenta es el de `BAAI/bge-m3` —se descarga solo el tokenizador—, para que
la ingesta cuente en los mismos tokens que el servidor.

El fragmento por defecto es de **512 tokens** con un quinto de solapamiento: con 8192 de
tope, «el fragmento más grande que cabe» ya no es un buen valor por defecto, y 512 es el
tamaño de las notas del curso. Cámbialo con `chunk_tokens` y justifícalo en el informe.

| `EMBEDDING_BACKEND` | Modelo (fila) | Tope | Hace falta |
|---|---|---|---|
| `h200` | `bge-m3` (`embed_local_multilingue`) | 8192 | VPN GlobalProtect |
| `openai` | `text-embedding-3-small` (`embed_api_economico`); `EMBEDDING_MODEL` elige otro | 8192 | `OPENAI_API_KEY` |
| `local` (configurado en `.env`) | `BAAI/bge-m3`; MiniLM en la Parte 0 | 8192; 128 con MiniLM | PyTorch con CUDA para GPU |

**Sin VPN puedes usar la GPU local o la API de OpenAI.** Lo que no se puede es **mezclar**: un índice
construido con un modelo solo se consulta con ese mismo modelo, así que si cambias de ruta,
reindexa. Y se declara en el informe con qué modelo se construyó el índice.

## La generación, y la abstención

`rag_pipeline.generate` elige la ruta por la clave disponible: `OPENAI_API_KEY` → fila
`propietario_economico`; `ANTHROPIC_API_KEY` → fila `juez_economico`; ninguna → Ollama con
la fila `open_weight_pequeno`; y sin Ollama, «modo inspección», que devuelve el prompt.
`GENERATION_MODEL` sobreescribe el modelo. Ningún nombre está escrito a mano en el código:
salen de la tabla semestral por su `id`.

La frase de abstención es **una** en todo el curso: `ABSTENCION` en `rag_pipeline.py`, la
misma en el prompt, en el golden set y en el notebook del miércoles. `se_abstuvo()` la
detecta **normalizada** (minúsculas, sin tildes, sin puntuación): con una tilde de más o un
punto final de menos, un detector por igualdad de cadena no dispararía nunca.

## Qué mide `evaluation.py`

| Métrica | Sobre qué | Qué significa |
|---|---|---|
| `hit_rate` | preguntas **respondibles** | ¿algún fragmento recuperado pertenece al documento fuente (y contiene el fragmento esperado, si lo diste)? |
| `mrr` | respondibles | media de 1/posición del primer acierto |
| `abstencion_correcta` | negativas | fracción en la que el sistema se abstuvo — lo correcto |
| `abstencion_indebida` | respondibles | fracción en la que se abstuvo — lo incorrecto |

Las negativas **no entran** en `hit_rate` ni en `mrr`: no hay nada que recuperar. Con la
plantilla anterior sí entraban, y un sistema perfecto reportaba 0,70 como techo.
`--sin-generar` salta el LLM: las dos tasas salen «sin medir» y las otras dos, igual.

El golden set se anota **por documento y por fragmento literal**, no por `chunk_id`: los
identificadores cambian al re-fragmentar y la Opción A del taller los invalidaba sin fallar.

## Recursos

- Qdrant docs: https://qdrant.tech/documentation (consultado 2026-09-19: `create_collection`
  + `query_points`; HNSW es el único índice denso, `m=16`, `ef_construct=100`)
- sentence-transformers: https://www.sbert.net
- RAGAS: https://docs.ragas.io
