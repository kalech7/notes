# Revisión final del experimento

Revisión realizada sobre las salidas guardadas el 27 de septiembre de 2026. Las métricas y las respuestas originales se conservan.

## Contraste de modelos

El anexo del enunciado (p. 9) confirma `embed_local_multilingue`: `BAAI/bge-m3`, 1024 dimensiones, 8192 tokens y `verified_at=2026-08-27`. Se ejecutó en CUDA local; el notebook del profesor, celda 21, recomienda `sentence-transformers` local como plan B y declararlo.

El generador medido es **gemma3:4b**, Q4_K_M, verificado localmente el 2026-09-27. Huella Ollama: `a2af6cc3eb7fa8be8504abaf9b04e88f17a119ec3f04a3addf55f92841195f5a`. Contexto configurado: 8192; temperatura: 0; máximo de salida: 512.

Contraste documental realizado. El generador medido es gemma3:4b. Su correspondencia con open_weight_pequeno no es verificable: ni el anexo ni el notebook del profesor proporcionan el nombre y verified_at de esa fila. GLM-5.3-Flash es el servicio remoto descrito, no prueba de la identidad de la fila local. El notebook del profesor declara GLM-5.3-Flash en la H200 con fecha 2026-09-22, pero no contiene la tabla semestral ni relaciona ese servicio con la fila local. **La fecha de verificación local no se presenta como `verified_at` del curso.**

## Diagnósticos revisados

### Caso 5: Recuperación: cobertura incompleta de una pregunta compuesta

**Pregunta:** Mi respuesta necesita dos pasajes, pero recibí cinco bloques casi iguales con una sola de esas piezas. ¿Por qué podría tener Hit Rate perfecto, qué cobertura obtengo y qué decisión de fragmentación puede causar esa repetición?

**Respuesta real:** El corpus no contiene información suficiente.

Hit@5=1 y RR@5=1/3 porque el ancla de la nota 43 llega en el puesto 3 (coseno 0,585577). Solo aparece una de las dos evidencias anotadas: cobertura literal 1/2. El pasaje que vincula solapamiento y duplicación existe en 37-0005, pero no entra en el top-5. La nota 41 recuperada explica que repetir información no aumenta diversidad, pero no aporta la causa concreta del solapamiento. El sistema se abstiene: cuenta como abstención indebida respecto del corpus, aunque el contexto entregado no respalda toda la respuesta. La consulta describe cinco bloques casi iguales como supuesto; los cinco vecinos medidos no son cinco duplicados. No se puede atribuir esa duplicación al chunking real del experimento.

Las dos fuentes fueron aceptadas por la ingesta y ambas anclas están completas en fragmentos indexados. Por tanto, para estas anclas la ausencia ocurre en la selección del top-5, no en el parseo ni en un corte que haya destruido la frase.

**Evidencia de ingesta:**

| Fuente | Caracteres útiles | Rechazada | Error |
| --- | --- | --- | --- |
| 37 S08 - Estrategias de fragmentación y solapamiento.md | 8497 | False | None |
| 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso.md | 5460 | False | None |

**Vecinos entregados al generador:**

| Puesto | Fragmento | Coseno |
| --- | --- | --- |
| 1 | 48 S09 - Diagnóstico experimentos y Taller 2-0001 | 0.60963930 |
| 2 | 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso-0000 | 0.58843935 |
| 3 | 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso-0001 | 0.58557710 |
| 4 | 41 S08 - Recordatorio y preguntas de comprensión-0005 | 0.54589450 |
| 5 | 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso-0005 | 0.54552600 |

**Anclas del golden:**

| Frase | En el índice | Puesto en top-5 |
| --- | --- | --- |
| Hit Rate no distingue recuperar una pieza de recuperar todas | 43 S09 - Hit Rate Recall MRR MAP y nDCG paso a paso-0001 | [3] |
| El solapamiento puede producir fragmentos casi idénticos | 37 S08 - Estrategias de fragmentación y solapamiento-0005 | Ausente |

**Acción propuesta:** Probar recuperación por las subpreguntas o selección de contexto con diversidad; exigir cobertura de ambas evidencias. La búsqueda híbrida medida adelanta el primer acierto del puesto 3 al 2, pero no trae 37-0005: mejora MRR sin resolver la cobertura.

**Alcance de la conclusión:** No se ha medido una segunda estrategia de fragmentación ni una generación con contexto reparado. No se afirma causalidad exclusiva del modelo generativo.


### Caso 4: Generación o interpretación del prompt: abstención con evidencia disponible

**Pregunta:** El texto que guardé al final de un bloque contiene la respuesta, pero el embedding se calculó con un prefijo y el generador se abstuvo. ¿Por qué ampliar su ventana no arregla la búsqueda y cómo se clasifica esa abstención si la respuesta sí está en las notas?

**Respuesta real:** El corpus no contiene información suficiente.

Hit@5=1 y RR@5=1/2. El puesto 2, 36-0002 (0,58533466), explica que el vector se calcula antes de buscar y que no se relee el payload. El puesto 1, 39-0005, explica que abstenerse puede ser prudente para el generador y revelar un fallo del recuperador; el puesto 5, 45-0002, clasifica la abstención sobre respondibles. La cobertura literal de las fuentes anotadas es 1/2, porque no llegó 45-0001, pero sí llegó evidencia semánticamente equivalente desde otras partes. Por eso esa cobertura literal no prueba insuficiencia del contexto. La respuesta fue la frase de abstención pese a que se podía construir una explicación apoyada en los pasajes.

Las fuentes se ingirieron y las anclas existen en el índice. En esta ejecución el máximo de fragmento observado fue 515 tokens con especiales, frente a un límite de 8192: no hay evidencia de truncamiento del embedding. El truncamiento descrito pertenece al supuesto de la pregunta, no al baseline observado.

**Evidencia de ingesta:**

| Fuente | Caracteres útiles | Rechazada | Error |
| --- | --- | --- | --- |
| 36 S08 - Fragmentos tokens y truncamiento.md | 7442 | False | None |
| 45 S09 - Preguntas negativas y abstención.md | 3981 | False | None |

**Vecinos entregados al generador:**

| Puesto | Fragmento | Coseno |
| --- | --- | --- |
| 1 | 39 S08 - Reranking contexto y abstención-0005 | 0.64709380 |
| 2 | 36 S08 - Fragmentos tokens y truncamiento-0002 | 0.58533466 |
| 3 | 49 S09 - Ejercicios resueltos y repaso-0001 | 0.58203240 |
| 4 | 37 S08 - Estrategias de fragmentación y solapamiento-0003 | 0.58117770 |
| 5 | 45 S09 - Preguntas negativas y abstención-0002 | 0.57875420 |

**Anclas del golden:**

| Frase | En el índice | Puesto en top-5 |
| --- | --- | --- |
| La búsqueda vectorial usa el vector | 36 S08 - Fragmentos tokens y truncamiento-0001, 36 S08 - Fragmentos tokens y truncamiento-0002 | [2] |
| abstenerse puede ser prudente para el generador | 45 S09 - Preguntas negativas y abstención-0001 | Ausente |

**Acción propuesta:** Comparar, en un experimento separado, la misma consulta con un contexto mínimo que incluya los pasajes 36-0002 y 39-0005, y una instrucción que pida responder cada subpregunta. Mantener consulta, contexto y modelo constantes al probar cambios del prompt.

**Alcance de la conclusión:** El registro permite localizar el fallo después de recuperar, pero no separar con certeza la contribución del prompt, los distractores y el modelo sin una prueba controlada. No se modifican las métricas del baseline.


### Caso 6: Recuperación de pasajes incorrectos y generación fuera de la pregunta

**Pregunta:** Voy a cambiar los cortes de mis apuntes y comparar el recuperador denso con uno híbrido. ¿Por qué debo recalcular BM25 y cómo mantengo una referencia de evaluación que siga apuntando a la evidencia correcta?

**Respuesta real:** Porque utiliza el orden de cada lista y no la magnitud original de los puntajes. Además, los efectos de $k_1$ y $b$ se deducen de la fórmula presentada; no son mediciones. Para mantener una referencia de evaluación que siga apuntando a la evidencia correcta, se debe revisar truncamiento y puntajes antes de fijar umbrales.

Hit@5=0, RR@5=0 y cobertura literal 0/2. El primer vecino es 38-0007 (0,641014), que explica por qué RRF combina escalas; la respuesta reproduce ese tema y lo presenta como motivo para recalcular BM25. También recomienda revisar truncamiento y umbrales en vez de anclar la evaluación a documento y frase. Los dos pasajes esperados están completos en 38-0001 y 44-0002, pero ninguno aparece en el top-5. Recuperar la nota 38 en otros fragmentos no equivale a recuperar la evidencia solicitada.

La ingesta aceptó las notas 38 y 44 y el índice conserva ambas frases completas. El contexto contiene información general sobre BM25, pero no el vínculo anotado entre cambiar cortes, frecuencias y longitudes ni la regla de referencia documental. La salida tampoco reconoce esa insuficiencia. Que copie texto del contexto no garantiza relevancia para la pregunta.

**Evidencia de ingesta:**

| Fuente | Caracteres útiles | Rechazada | Error |
| --- | --- | --- | --- |
| 38 S08 - Búsqueda léxica densa y fusión RRF.md | 10534 | False | None |
| 44 S09 - Golden sets anotación y caducidad.md | 5535 | False | None |

**Vecinos entregados al generador:**

| Puesto | Fragmento | Coseno |
| --- | --- | --- |
| 1 | 38 S08 - Búsqueda léxica densa y fusión RRF-0007 | 0.64101374 |
| 2 | 38 S08 - Búsqueda léxica densa y fusión RRF-0000 | 0.62805545 |
| 3 | 41 S08 - Recordatorio y preguntas de comprensión-0001 | 0.59269357 |
| 4 | 30 S06 - Cómo se entrena SBERT y por qué permite buscar-0002 | 0.59124714 |
| 5 | 32 S06 - Elegir modelo y reconocer límites-0002 | 0.58754520 |

**Anclas del golden:**

| Frase | En el índice | Puesto en top-5 |
| --- | --- | --- |
| Al cambiar los fragmentos cambian longitudes y frecuencias documentales | 38 S08 - Búsqueda léxica densa y fusión RRF-0001 | Ausente |
| fija la referencia en el documento y en una frase | 44 S09 - Golden sets anotación y caducidad-0002 | Ausente |

**Acción propuesta:** Reformular o descomponer la consulta para cubrir cambios de fragmentación y estabilidad del golden set; comprobar cobertura antes de generar. La extensión BM25+RRF ensayada también deja Hit@5=0 para este caso, así que no se presenta como solución demostrada.

**Alcance de la conclusión:** No se ha ensayado reranking ni se atribuye el fallo a Qdrant: faltaría comparar candidatos y selección para aislar sus causas.


## Interpretación de la extensión

La hipótesis se registró antes de medir la extensión en `evidencias/hipotesis_extension.json`.
Los casos 5 y 6 permiten justificar una prueba de recuperación: hay evidencia indexada que el top-5 omite.
Eso no demuestra que la causa sea únicamente vocabulario ni que BM25 vaya a corregirla. El caso 4 apunta
además a generación y no queda resuelto por una mejora de ranking.

Con k=3, la fusión pierde el acierto de la pregunta 10: su primer fragmento relevante pasa del puesto 1
al 4. Hit Rate baja de 7/8 a 6/8, mientras MRR se mantiene en 0,5625 porque las preguntas 2, 3, 4 y 5
adelantan sus primeros aciertos. Con k=5, ambos métodos aciertan 7/8; esos adelantos compensan
parcialmente la caída de la pregunta 10 y MRR pasa de 0,5625 a 0,59375 (Δ=0,03125).
La pregunta 6 sigue sin acierto y la 5 sigue sin el pasaje esperado sobre duplicación por solapamiento.

**Decisión:** conservar el recuperador denso como baseline. No hay una mejora uniforme que justifique
sustituirlo: la extensión queda como comparación medida, con un pequeño beneficio de orden en k=5
y una pérdida en k=3. No se generaron respuestas de la extensión; por tanto, no se le atribuyen
mejoras de abstención ni de calidad final. Ocho preguntas respondibles no permiten generalizar.


| Pregunta | k | Puesto denso | Puesto híbrido | Δ RR |
| --- | --- | --- | --- | --- |
| 2 | 3 | 3 | 2 | +0.166667 |
| 3 | 3 | 3 | 2 | +0.166667 |
| 4 | 3 | 2 | 1 | +0.500000 |
| 5 | 3 | 3 | 2 | +0.166667 |
| 10 | 3 | 1 | Sin acierto | -1.000000 |
| 2 | 5 | 3 | 2 | +0.166667 |
| 3 | 5 | 3 | 2 | +0.166667 |
| 4 | 5 | 2 | 1 | +0.500000 |
| 5 | 5 | 3 | 2 | +0.166667 |
| 10 | 5 | 1 | 4 | -0.750000 |

## Otras limitaciones observadas

En k=3, la respuesta 1 primero afirma que el ranking se conserva y después que puede cambiar:
es una contradicción que Hit Rate y MRR no detectan. En k=5 la explicación sí distingue orden y escala.
La adversarial 9 se abstiene en k=3 y responde 0,6 en k=5, sin repetir la instrucción maliciosa;
un solo caso no demuestra robustez general. Las tasas de abstención no son métricas de fidelidad.

La revisión causal quedó realizada por Codex sobre los registros. No equivale a una revisión docente
ni a una validación experimental de cada intervención propuesta. El único dato externo que falta
para comprobar la identidad de la fila local oficial es `modelos-2026-1.json` o una fuente del curso
que publique su modelo y `verified_at`. Se mantiene como no verificable, sin inventarlo.
